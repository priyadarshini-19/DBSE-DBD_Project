const API_BASE = (import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000").replace(/\/$/, "");

export async function api(path, { token, ...options } = {}) {
  const authToken = token || localStorage.getItem("sportsyncToken");
  const headers = new Headers(options.headers || {});
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (authToken) headers.set("Authorization", `Bearer ${authToken}`);
  let response;
  try { response = await fetch(`${API_BASE}${path}`, { ...options, headers }); }
  catch { throw new Error(`Cannot reach the SportSync API at ${API_BASE}. Make sure the backend is running (uvicorn app.main:app --reload) and look at its terminal for errors.`); }
  const body = await response.json().catch(() => ({}));
  if (response.status === 401 && authToken && !path.startsWith("/api/auth/login")) {
    // Token expired or invalid: clear the session and return to the login screen.
    localStorage.removeItem("sportsyncToken");
    localStorage.removeItem("sportsyncCurrentUser");
    window.location.reload();
    throw new Error("Your session expired. Please log in again.");
  }
  if (!response.ok) {
    const detail = body.detail;
    const message = Array.isArray(detail) ? detail.map(x => x.msg || JSON.stringify(x)).join(", ") : typeof detail === "string" ? detail : `Request failed (${response.status})`;
    throw new Error(message);
  }
  return body;
}

const post = (path, payload, token) => api(path, { method: "POST", body: JSON.stringify(payload), token });

export const authApi = {
  register: payload => post("/api/auth/register", payload),
  login: payload => post("/api/auth/login", payload),
  me: token => api("/api/auth/me", { token }),
};
export const sportsApi = {
  list: token => api("/api/sports", { token }),
  create: (payload, token) => post("/api/sports", payload, token),
  sessions: token => api("/api/sessions", { token }),
  createSession: (payload, token) => post("/api/sessions", payload, token),
  updateSession: (id, payload, token) => api(`/api/sessions/${id}`, { method: "PUT", body: JSON.stringify(payload), token }),
  deleteSession: (id, token) => api(`/api/sessions/${id}`, { method: "DELETE", token }),
};
export const coachesApi = { list: token => api("/api/coaches", { token }) };
export const usersApi = { list: token => api("/api/users", { token }), getAll: token => api("/api/users", { token }) };
export const participantsApi = { list: token => api("/api/participants", { token }), join: (sessionId, token) => post("/api/participants", { session_id: sessionId }, token) };
export const performanceApi = { list: token => api("/api/performance", { token }) };
export const notificationsApi = { list: token => api("/api/notifications", { token }) };
export const authLogsApi = { list: token => api("/api/auth-logs", { token }) };

// Data that feeds the dashboards (all read from MySQL through the API)
export const dashboardApi = {
  summary: token => api("/api/dashboard/summary", { token }),
  athlete: token => api("/api/dashboard/athlete", { token }),
  coach: token => api("/api/dashboard/coach", { token }),
  organizer: token => api("/api/dashboard/organizer", { token }),
};
export const tablesApi = { get: (name, token) => api(`/api/tables/${encodeURIComponent(name)}`, { token }) };
