import React, { useState } from "react";
import { sportsApi } from "../services-api";

const EMPTY = { session_name: "", sport_id: "", coach_id: "", session_date: "", session_time: "", location: "" };

const STATUSES = ["scheduled", "ongoing", "completed", "cancelled"];

// Turns a Sessions row from the API into form values ("16:30:00" -> "16:30").
function toForm(session) {
  return {
    session_name: session.session_name || "",
    sport_id: session.sport_id ? String(session.sport_id) : "",
    coach_id: session.coach_id ? String(session.coach_id) : "",
    session_date: session.session_date ? String(session.session_date).slice(0, 10) : "",
    session_time: session.session_time ? String(session.session_time).slice(0, 5) : "",
    location: session.location || "",
    status: session.status || "scheduled",
  };
}

// Creates a row in the Sessions table, or edits one when `initial` (an existing session) is passed.
// Pass `coaches` to show a coach picker (organizers); coaches creating their own session omit it
// and the API assigns them automatically.
export default function SessionForm({ sports = [], coaches = null, initial = null, onCreated, onCancel }) {
  const editing = Boolean(initial);
  const [form, setForm] = useState(initial ? toForm(initial) : { ...EMPTY, status: "scheduled" });
  const [message, setMessage] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  const change = (field) => (e) => {
    setForm((old) => ({ ...old, [field]: e.target.value }));
    setMessage({ type: "", text: "" });
  };

  async function submit(e) {
    e.preventDefault();
    if (form.session_name.trim().length < 2) { setMessage({ type: "error", text: "Enter a session name." }); return; }
    if (!form.sport_id) { setMessage({ type: "error", text: "Select a sport." }); return; }
    setSaving(true);
    try {
      const payload = {
        session_name: form.session_name.trim(),
        sport_id: Number(form.sport_id),
        coach_id: coaches && form.coach_id ? Number(form.coach_id) : null,
        session_date: form.session_date || null,
        session_time: form.session_time || null,
        location: form.location.trim() || null,
        status: editing ? form.status : "scheduled",
      };
      const token = localStorage.getItem("sportsyncToken");
      const created = editing
        ? await sportsApi.updateSession(initial.session_id, payload, token)
        : await sportsApi.createSession(payload, token);
      if (!editing) setForm({ ...EMPTY, status: "scheduled" });
      setMessage({ type: "success", text: editing ? "Session updated successfully." : "Session created successfully." });
      if (onCreated) onCreated(created);
    } catch (error) {
      setMessage({ type: "error", text: error.message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="session-form" onSubmit={submit}>
      <div className="input-group">
        <label>Session Name</label>
        <input type="text" placeholder="Example: Evening Football Practice" value={form.session_name} onChange={change("session_name")} />
      </div>
      <div className="input-group">
        <label>Sport</label>
        <select value={form.sport_id} onChange={change("sport_id")}>
          <option value="">-- Select Sport --</option>
          {sports.map((s) => (
            <option key={s.sport_id} value={s.sport_id}>{s.sport_name}</option>
          ))}
        </select>
      </div>
      {coaches && (
        <div className="input-group">
          <label>Coach</label>
          <select value={form.coach_id} onChange={change("coach_id")}>
            <option value="">-- Not assigned --</option>
            {coaches.map((c) => (
              <option key={c.coach_id} value={c.coach_id}>
                {c.coach_name}{c.sport_name ? ` (${c.sport_name})` : ""}
              </option>
            ))}
          </select>
        </div>
      )}
      <div className="input-group">
        <label>Date</label>
        <input type="date" value={form.session_date} onChange={change("session_date")} />
      </div>
      <div className="input-group">
        <label>Time</label>
        <input type="time" value={form.session_time} onChange={change("session_time")} />
      </div>
      <div className="input-group">
        <label>Location</label>
        <input type="text" placeholder="Example: Ground 1" value={form.location} onChange={change("location")} />
      </div>
      {editing && (
        <div className="input-group">
          <label>Status</label>
          <select value={form.status} onChange={change("status")}>
            {STATUSES.map((st) => (
              <option key={st} value={st}>{st.charAt(0).toUpperCase() + st.slice(1)}</option>
            ))}
          </select>
        </div>
      )}
      <div className="session-form-actions">
        <button type="submit" className="primary-btn" disabled={saving}>
          {saving ? "SAVING…" : editing ? "SAVE CHANGES" : "CREATE SESSION"}
        </button>
        {onCancel && (
          <button type="button" className="secondary-btn" onClick={onCancel}>Close</button>
        )}
      </div>
      {message.text && (
        <p className={message.type === "success" ? "organizer-success" : "organizer-error"} role="status">
          {message.text}
        </p>
      )}
    </form>
  );
}
