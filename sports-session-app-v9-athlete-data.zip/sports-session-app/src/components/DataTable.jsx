import React from "react";

function DataTable({ tableName, currentUser }) {

  const data = {

    Users: [
      {
        "USER ID": 101,
        Name: "Priyadarshini",
        Email: "priya@gmail.com",
        Role: "Coach",
        "Sport ID": 1,
      },
      {
        "USER ID": 102,
        Name: "Rahul",
        Email: "rahul@gmail.com",
        Role: "Athlete",
        "Sport ID": 2,
      },
    ],

    Sports: [
      {
        "SPORT ID": 1,
        "SPORT NAME": "Swimming",
        Category: "Individual",
        Status: "Active",
      },
      {
        "SPORT ID": 2,
        "SPORT NAME": "Cricket",
        Category: "Team",
        Status: "Active",
      },
      {
        "SPORT ID": 3,
        "SPORT NAME": "Football",
        Category: "Team",
        Status: "Active",
      },
      {
        "SPORT ID": 4,
        "SPORT NAME": "Badminton",
        Category: "Individual",
        Status: "Active",
      },
      {
        "SPORT ID": 5,
        "SPORT NAME": "Basketball",
        Category: "Team",
        Status: "Active",
      },
    ],

    Sessions: [
      {
        "SESSION ID": 201,
        "SPORT ID": 1,
        "SESSION NAME": "Swimming Practice",
        Date: "22 Sep 2026",
        Status: "Scheduled",
      },
      {
        "SESSION ID": 202,
        "SPORT ID": 2,
        "SESSION NAME": "Cricket Training",
        Date: "23 Sep 2026",
        Status: "Scheduled",
      },
      {
        "SESSION ID": 203,
        "SPORT ID": 3,
        "SESSION NAME": "Football Match",
        Date: "24 Sep 2026",
        Status: "Scheduled",
      },
      {
        "SESSION ID": 204,
        "SPORT ID": 4,
        "SESSION NAME": "Badminton Session",
        Date: "25 Sep 2026",
        Status: "Scheduled",
      },
    ],

    "Session Participants": [
      {
        "PARTICIPANT ID": 301,
        "SESSION ID": 201,
        "USER ID": 101,
        Role: "Coach",
      },
      {
        "PARTICIPANT ID": 302,
        "SESSION ID": 202,
        "USER ID": 102,
        Role: "Athlete",
      },
      {
        "PARTICIPANT ID": 303,
        "SESSION ID": 203,
        "USER ID": 102,
        Role: "Athlete",
      },
      {
        "PARTICIPANT ID": 304,
        "SESSION ID": 204,
        "USER ID": 101,
        Role: "Coach",
      },
    ],

    Performance: [
      {
        "PERFORMANCE ID": 401,
        "USER ID": 101,
        "SPORT ID": 1,
        Score: 92,
        Rating: "Excellent",
      },
      {
        "PERFORMANCE ID": 402,
        "USER ID": 102,
        "SPORT ID": 2,
        Score: 86,
        Rating: "Very Good",
      },
      {
        "PERFORMANCE ID": 403,
        "USER ID": 102,
        "SPORT ID": 3,
        Score: 89,
        Rating: "Very Good",
      },
      {
        "PERFORMANCE ID": 404,
        "USER ID": 101,
        "SPORT ID": 4,
        Score: 94,
        Rating: "Excellent",
      },
    ],

    Notifications: [
      {
        "NOTIFICATION ID": 501,
        "USER ID": 101,
        Message: "Swimming session scheduled",
        Date: "21 Sep 2026",
        Status: "Unread",
      },
      {
        "NOTIFICATION ID": 502,
        "USER ID": 102,
        Message: "Cricket training tomorrow",
        Date: "21 Sep 2026",
        Status: "Unread",
      },
      {
        "NOTIFICATION ID": 503,
        "USER ID": 101,
        Message: "Performance updated",
        Date: "20 Sep 2026",
        Status: "Read",
      },
    ],

    "Auth Logs": [
      {
        "LOG ID": 601,
        "USER ID": 101,
        Action: "Login",
        Date: "21 Sep 2026",
        Status: "Success",
      },
      {
        "LOG ID": 602,
        "USER ID": 102,
        Action: "Login",
        Date: "21 Sep 2026",
        Status: "Success",
      },
      {
        "LOG ID": 603,
        "USER ID": 101,
        Action: "Logout",
        Date: "20 Sep 2026",
        Status: "Success",
      },
    ],
  };

  let rows = data[tableName] || [];

  // Add currently registered user if not already present
  if (
    tableName === "Users" &&
    currentUser &&
    !rows.some(
      (row) =>
        row.Email?.toLowerCase() ===
        currentUser.email?.toLowerCase()
    )
  ) {
    rows = [
      ...rows,
      {
        "USER ID": currentUser.id,
        Name: currentUser.name,
        Email: currentUser.email,
        Role: currentUser.role,
        "Sport ID": "-",
      },
    ];
  }

  if (rows.length === 0) {
    return (
      <div className="empty-table">
        No data available.
      </div>
    );
  }

  const columns = Object.keys(rows[0]);

  return (
    <div className="data-table-container">

      <div className="data-table-header">

        <h2>
          {tableName}
        </h2>

        <span>
          {rows.length} Records
        </span>

      </div>

      <div className="table-scroll">

        <table>

          <thead>
            <tr>
              {columns.map((column) => (
                <th key={column}>
                  {column}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>

            {rows.map((row, rowIndex) => (
              <tr key={rowIndex}>

                {columns.map((column) => (
                  <td key={column}>
                    {row[column]}
                  </td>
                ))}

              </tr>
            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default DataTable;