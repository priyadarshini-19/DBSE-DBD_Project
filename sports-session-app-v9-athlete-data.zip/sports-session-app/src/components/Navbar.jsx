import React from "react";

function Navbar({
  user,
  onLogout,
  onMenuClick,
}) {
  return (
    <header className="top-header">

      <button
        className="menu-button"
        onClick={onMenuClick}
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <div className="brand-center">

        <div className="brand-title">
          🏆 SportSync
        </div>

        <div className="brand-subtitle">
          SPORTS & ATHLETICS
        </div>

      </div>

      <div className="user-area">

        <div className="user-avatar">
          {user?.name
            ? user.name.charAt(0).toUpperCase()
            : "U"}
        </div>

        <div className="user-details">

          <strong>
            {user?.name || "User"}
          </strong>

          <span>
            {user?.role || "Athlete"}
          </span>

          <small>
            {user?.sport || "Sports"}
          </small>

        </div>

        <button
          className="logout-btn"
          onClick={onLogout}
        >
          Logout
        </button>

      </div>

    </header>
  );
}

export default Navbar;