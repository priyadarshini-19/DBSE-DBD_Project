import React, { useEffect, useState } from "react";

function BackgroundSlider() {

  const images = [
    "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=1920&q=85",
    "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1920&q=85",
    "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=1920&q=85",
    "https://images.unsplash.com/photo-1530549387789-4c1017266635?auto=format&fit=crop&w=1920&q=85",
    "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=1920&q=85",
  ];

  const [current, setCurrent] = useState(0);

  useEffect(() => {

    const timer = setInterval(() => {

      setCurrent(
        (previous) =>
          (previous + 1) % images.length
      );

    }, 5000);

    return () => clearInterval(timer);

  }, [images.length]);


  return (
    <div className="background-slider">

      {images.map((image, index) => (

        <div
          key={image}
          className={`background-slide ${
            index === current
              ? "active"
              : ""
          }`}
          style={{
            backgroundImage:
              `url("${image}")`,
          }}
        />

      ))}

      <div className="background-overlay" />

    </div>
  );
}

export default BackgroundSlider;