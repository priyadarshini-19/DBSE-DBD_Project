import React from "react";

function TableCard({
  name,
  icon,
  description,
  onClick,
}) {
  return (
    <button
      className="table-card"
      onClick={onClick}
    >
      <div className="table-card-icon">
        {icon}
      </div>

      <div className="table-card-content">
        <h3>{name}</h3>
        <p>{description}</p>
      </div>
    </button>
  );
}

export default TableCard;