import React, { useState } from "react";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";

import AthleteDashboard from "./pages/AthleteDashboard";
import CoachDashboard from "./pages/CoachDashboard";
import OrganizerDashboard from "./pages/OrganizerDashboard";

import BackgroundSlider from "./components/BackgroundSlider";

import "./App.css";

function App() {

  // =====================================================
  // 1. CHECK IF USER IS ALREADY LOGGED IN
  // =====================================================

  const savedUser = JSON.parse(
    localStorage.getItem("sportsyncCurrentUser") || "null"
  );


  // =====================================================
  // 2. STORE CURRENT USER
  // =====================================================

  const [currentUser, setCurrentUser] = useState(
    savedUser
  );


  // =====================================================
  // 3. STORE CURRENT PAGE
  // =====================================================
  //
  // Possible values:
  //
  // "login"
  // "register"
  // "dashboard"
  // "athlete"
  // "coach"
  // "organizer"
  //
  // =====================================================

  const [page, setPage] = useState(
    savedUser ? "dashboard" : "login"
  );


  // =====================================================
  // 4. LOGIN FUNCTION
  // =====================================================

  const handleLogin = (user) => {

    // Store user in React state
    setCurrentUser(user);

    // Store user in browser
    localStorage.setItem(
      "sportsyncCurrentUser",
      JSON.stringify(user)
    );

    // After login → NORMAL DASHBOARD
    setPage("dashboard");
  };


  // =====================================================
  // 5. REGISTER FUNCTION
  // =====================================================

  const handleRegister = (newUser) => {

    // Do not automatically login
    setCurrentUser(null);

    // Remove previous login
    localStorage.removeItem(
      "sportsyncCurrentUser"
    );

    // After registration → LOGIN PAGE
    setPage("login");
  };


  // =====================================================
  // 6. LOGOUT FUNCTION
  // =====================================================

  const handleLogout = () => {

    // Remove user from React
    setCurrentUser(null);

    // Remove saved login
    localStorage.removeItem(
      "sportsyncCurrentUser"
    );
    localStorage.removeItem("sportsyncToken");

    // Return to login
    setPage("login");
  };


  // =====================================================
  // 7. OPEN MY ROLE DASHBOARD
  // =====================================================
  //
  // This function is called when the user clicks:
  //
  // My Athlete Dashboard
  // My Coach Dashboard
  // My Organizer Dashboard
  //
  // =====================================================

  const openMyDashboard = () => {

    // Safety check
    if (!currentUser) {
      return;
    }


    // -----------------------------------------------
    // ATHLETE
    // -----------------------------------------------

    if (currentUser.role.toLowerCase() === "athlete") {

      setPage("athlete");

      return;
    }


    // -----------------------------------------------
    // COACH
    // -----------------------------------------------

    if (currentUser.role.toLowerCase() === "coach") {

      setPage("coach");

      return;
    }


    // -----------------------------------------------
    // ORGANIZER
    // -----------------------------------------------

    if (["organizer", "admin"].includes(currentUser.role.toLowerCase())) {

      setPage("organizer");

      return;
    }


    // -----------------------------------------------
    // DEFAULT
    // -----------------------------------------------

    setPage("dashboard");
  };


  // =====================================================
  // 8. RETURN TO NORMAL DASHBOARD
  // =====================================================

  const goToDashboard = () => {

    setPage("dashboard");
  };


  // =====================================================
  // 9. MAIN APPLICATION UI
  // =====================================================

  return (
    <div className="app-container">

      {/* =================================================
          BACKGROUND SLIDESHOW
          ================================================= */}

      <BackgroundSlider />


      {/* =================================================
          LOGIN PAGE
          ================================================= */}

      {page === "login" && (

        <Login
          onLogin={handleLogin}

          goToRegister={() =>
            setPage("register")
          }
        />

      )}


      {/* =================================================
          REGISTER PAGE
          ================================================= */}

      {page === "register" && (

        <Register
          onRegister={handleRegister}

          goToLogin={() =>
            setPage("login")
          }
        />

      )}


      {/* =================================================
          NORMAL DASHBOARD
          ================================================= */}

      {page === "dashboard" && currentUser && (

        <Dashboard
          user={currentUser}

          onLogout={handleLogout}

          onOpenMyDashboard={
            openMyDashboard
          }
        />

      )}


      {/* =================================================
          ATHLETE DASHBOARD
          ================================================= */}

      {page === "athlete" && currentUser && (

        <AthleteDashboard
          user={currentUser}

          onBack={goToDashboard}

          onLogout={handleLogout}
        />

      )}


      {/* =================================================
          COACH DASHBOARD
          ================================================= */}

      {page === "coach" && currentUser && (

        <CoachDashboard
          user={currentUser}

          onBack={goToDashboard}

          onLogout={handleLogout}
        />

      )}


      {/* =================================================
          ORGANIZER DASHBOARD
          ================================================= */}

      {page === "organizer" && currentUser && (

        <OrganizerDashboard
          user={currentUser}

          onBack={goToDashboard}

          onLogout={handleLogout}
        />

      )}

    </div>
  );
}

export default App;