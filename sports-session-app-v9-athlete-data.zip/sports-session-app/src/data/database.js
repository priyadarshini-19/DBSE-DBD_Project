const database = {

  Users: [
    {
      User_ID: 101,
      Name: "Priyadarshini",
      Email: "priya@gmail.com",
      Role: "Coach",
      Sport_ID: 1,
    },
    {
      User_ID: 102,
      Name: "Rahul",
      Email: "rahul@gmail.com",
      Role: "Athlete",
      Sport_ID: 2,
    },
  ],


  Sports: [
    {
      Sport_ID: 1,
      Sport_Name: "Swimming",
      Category: "Individual",
    },
    {
      Sport_ID: 2,
      Sport_Name: "Cricket",
      Category: "Team",
    },
    {
      Sport_ID: 3,
      Sport_Name: "Football",
      Category: "Team",
    },
    {
      Sport_ID: 4,
      Sport_Name: "Basketball",
      Category: "Team",
    },
    {
      Sport_ID: 5,
      Sport_Name: "Badminton",
      Category: "Individual",
    },
  ],


  Sessions: [
    {
      Session_ID: 1,
      Sport_ID: 1,
      Session_Name: "Swimming Training",
      Date: "2026-09-22",
      Time: "07:00 AM",
    },
    {
      Session_ID: 2,
      Sport_ID: 2,
      Session_Name: "Cricket Practice",
      Date: "2026-09-23",
      Time: "05:00 PM",
    },
    {
      Session_ID: 3,
      Sport_ID: 3,
      Session_Name: "Football Match",
      Date: "2026-09-24",
      Time: "04:00 PM",
    },
    {
      Session_ID: 4,
      Sport_ID: 5,
      Session_Name: "Badminton Training",
      Date: "2026-09-25",
      Time: "06:00 PM",
    },
  ],


  Session_Participants: [
    {
      Participant_ID: 1,
      Session_ID: 1,
      User_ID: 101,
      Status: "Confirmed",
    },
    {
      Participant_ID: 2,
      Session_ID: 2,
      User_ID: 102,
      Status: "Confirmed",
    },
    {
      Participant_ID: 3,
      Session_ID: 3,
      User_ID: 102,
      Status: "Pending",
    },
    {
      Participant_ID: 4,
      Session_ID: 4,
      User_ID: 101,
      Status: "Confirmed",
    },
  ],


  Performance: [
    {
      Performance_ID: 1,
      User_ID: 101,
      Sport_ID: 1,
      Score: 88,
      Rating: "Excellent",
    },
    {
      Performance_ID: 2,
      User_ID: 102,
      Sport_ID: 2,
      Score: 82,
      Rating: "Very Good",
    },
    {
      Performance_ID: 3,
      User_ID: 102,
      Sport_ID: 3,
      Score: 76,
      Rating: "Good",
    },
    {
      Performance_ID: 4,
      User_ID: 101,
      Sport_ID: 5,
      Score: 91,
      Rating: "Excellent",
    },
  ],


  Notifications: [
    {
      Notification_ID: 1,
      User_ID: 101,
      Message: "Swimming session starts tomorrow.",
      Status: "Unread",
    },
    {
      Notification_ID: 2,
      User_ID: 102,
      Message: "Cricket practice has been confirmed.",
      Status: "Read",
    },
    {
      Notification_ID: 3,
      User_ID: 101,
      Message: "Your performance has been updated.",
      Status: "Unread",
    },
  ],


  AuthLogs: [
    {
      Log_ID: 1,
      User_ID: 101,
      Action: "Login",
      Date: "2026-09-21",
      Status: "Success",
    },
    {
      Log_ID: 2,
      User_ID: 102,
      Action: "Login",
      Date: "2026-09-21",
      Status: "Success",
    },
  ],

};

export default database;