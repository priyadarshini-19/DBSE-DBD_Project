import React, { useEffect, useRef, useState } from "react";
import { dashboardApi, sportsApi } from "../services-api";
import SessionForm from "../components/SessionForm";
import { sessionWhen, sportIcon, todayISO } from "../utils";

function OrganizerDashboard({ user, onBack, onLogout }) {
  const token = localStorage.getItem("sportsyncToken");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  const [showAddSport, setShowAddSport] = useState(false);
  const [sportName, setSportName] = useState("");
  const [sportMessage, setSportMessage] = useState("");
  const [saving, setSaving] = useState(false);

  const [showSessionForm, setShowSessionForm] = useState(false);
  const [showAllSessions, setShowAllSessions] = useState(false);
  const [notice, setNotice] = useState("");
  const scheduleRef = useRef(null);
  const editRef = useRef(null);

  // "update" / "remove" turn the schedule list into an edit / delete list
  const [mode, setMode] = useState(null);
  const [editingSession, setEditingSession] = useState(null);
  const [removingId, setRemovingId] = useState(null);

  useEffect(() => {
    let alive = true;
    dashboardApi.organizer(token)
      .then((result) => { if (alive) { setData(result); setError(""); } })
      .catch((e) => { if (alive) setError(e.message); });
    return () => { alive = false; };
  }, [token, reloadKey]);

  const sports = data ? data.sports : [];
  const sessions = data ? data.sessions : [];
  const coaches = data ? data.coaches : [];
  const stats = data ? data.stats : null;

  const today = todayISO();
  const scheduled = sessions
    .filter((s) => s.status === "scheduled")
    .sort((a, b) => String(a.session_date || "").localeCompare(String(b.session_date || "")));
  const upcomingCount = scheduled.filter((s) => s.session_date && s.session_date >= today).length;
  const visibleSessions = showAllSessions || mode ? sessions : scheduled.slice(0, 8);

  const addSport = async (e) => {
    e.preventDefault();
    setSportMessage("");
    const trimmed = sportName.trim();
    if (trimmed.length < 2) { setSportMessage("Please enter a sport name."); return; }
    if (sports.some((s) => s.sport_name.toLowerCase() === trimmed.toLowerCase())) {
      setSportMessage("This sport already exists.");
      return;
    }
    setSaving(true);
    try {
      await sportsApi.create({ sport_name: trimmed }, token);
      setSportName("");
      setSportMessage("Sport added successfully.");
      setReloadKey((n) => n + 1);
    } catch (err) {
      setSportMessage(err.message);
    } finally {
      setSaving(false);
    }
  };

  const scrollToSchedule = () => {
    setTimeout(() => {
      if (scheduleRef.current) scheduleRef.current.scrollIntoView({ behavior: "smooth" });
    }, 50);
  };
  const openSessionForm = () => { setShowSessionForm(true); setEditingSession(null); setMode(null); setNotice(""); };
  const viewSchedule = () => {
    setShowAllSessions(true);
    setMode(null);
    setEditingSession(null);
    scrollToSchedule();
  };
  const startUpdate = () => {
    setMode("update");
    setShowSessionForm(false);
    setEditingSession(null);
    setNotice("Update Schedule: click Edit next to the session you want to change.");
    scrollToSchedule();
  };
  const startRemove = () => {
    setMode("remove");
    setShowSessionForm(false);
    setEditingSession(null);
    setNotice("Remove Schedule: click Remove next to the session you want to delete.");
    scrollToSchedule();
  };
  const stopMode = () => { setMode(null); setEditingSession(null); setNotice(""); };

  const editSession = (session) => {
    setEditingSession(session);
    setNotice("");
    setTimeout(() => {
      if (editRef.current) editRef.current.scrollIntoView({ behavior: "smooth" });
    }, 50);
  };

  const removeSession = async (session) => {
    const joined = Number(session.participant_count) || 0;
    const warning = joined > 0
      ? `\n\n${joined} participant record(s) and any performance records for this session will also be deleted.`
      : "";
    if (!window.confirm(`Remove "${session.session_name}" from the schedule?${warning}\n\nThis cannot be undone.`)) return;
    setRemovingId(session.session_id);
    setNotice("");
    try {
      await sportsApi.deleteSession(session.session_id, token);
      setNotice(`"${session.session_name}" was removed from the schedule.`);
      setReloadKey((n) => n + 1);
    } catch (err) {
      setNotice(err.message);
    } finally {
      setRemovingId(null);
    }
  };

  return (
    <div className="my-dashboard-page">

      <header className="my-dashboard-header">
        <button className="my-back-button" onClick={onBack}>← Dashboard</button>
        <div className="my-brand"><h1>SportSync</h1><p>SPORTS & ATHLETICS</p></div>
        <button className="my-logout-button" onClick={onLogout}>Logout</button>
      </header>

      <main className="my-dashboard-content">

        <section className="my-welcome-card">
          <div className="my-profile-icon">📋</div>
          <div>
            <span className="my-label">MY {String(user.role || "Organizer").toUpperCase()} DASHBOARD</span>
            <h2>Welcome, {user.name}</h2>
            <p>Sports & Schedule Management</p>
          </div>
        </section>

        {error && <p className="error-message" role="alert">{error}</p>}
        {notice && <p className="organizer-success" role="status">{notice}</p>}
        {!data && !error && <p className="loading-note">Loading data from the database…</p>}

        <section className="my-stat-grid">
          <div className="my-stat-card"><div className="my-stat-icon">🏅</div><div><span>Total Sports</span><strong>{stats ? stats.sports : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">📅</div><div><span>Scheduled Sessions</span><strong>{stats ? stats.scheduled_sessions : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">🗓️</div><div><span>Upcoming Events</span><strong>{data ? upcomingCount : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">👥</div><div><span>Participants</span><strong>{stats ? stats.participants : "…"}</strong></div></div>
        </section>

        {/* ADD SPORT */}
        <section className="organizer-add-section">
          <div className="organizer-section-heading">
            <div>
              <span>🏅 SPORTS MANAGEMENT</span>
              <h3>Add a New Sport</h3>
              <p>Add sports that can be used when creating sessions and schedules.</p>
            </div>
            <button className="organizer-add-button" onClick={() => setShowAddSport(!showAddSport)}>
              {showAddSport ? "✕ Close" : "＋ Add Sport"}
            </button>
          </div>

          {showAddSport && (
            <form className="add-sport-form single" onSubmit={addSport}>
              <div className="input-group">
                <label>Sport Name</label>
                <input
                  type="text"
                  placeholder="Example: Kabaddi"
                  value={sportName}
                  onChange={(e) => { setSportName(e.target.value); setSportMessage(""); }}
                />
              </div>
              <button type="submit" className="primary-btn" disabled={saving}>
                {saving ? "SAVING…" : "ADD SPORT"}
              </button>
              {sportMessage && (
                <p className={sportMessage.includes("successfully") ? "organizer-success" : "organizer-error"}>
                  {sportMessage}
                </p>
              )}
            </form>
          )}
        </section>

        {/* CREATE SESSION */}
        {showSessionForm && (
          <section className="organizer-add-section">
            <div className="organizer-section-heading">
              <div>
                <span>📅 SCHEDULE</span>
                <h3>Create a Session</h3>
                <p>The new session is saved to the Sessions table.</p>
              </div>
            </div>
            <SessionForm
              sports={sports}
              coaches={coaches}
              onCreated={() => setReloadKey((n) => n + 1)}
              onCancel={() => setShowSessionForm(false)}
            />
          </section>
        )}

        {/* UPDATE SESSION */}
        {editingSession && (
          <section className="organizer-add-section" ref={editRef}>
            <div className="organizer-section-heading">
              <div>
                <span>✏️ UPDATE SCHEDULE</span>
                <h3>Edit “{editingSession.session_name}”</h3>
                <p>Changes are saved to the Sessions table.</p>
              </div>
            </div>
            <SessionForm
              key={editingSession.session_id}
              sports={sports}
              coaches={coaches}
              initial={editingSession}
              onCreated={() => {
                setReloadKey((n) => n + 1);
                setEditingSession(null);
                setNotice("Session updated successfully.");
              }}
              onCancel={() => setEditingSession(null)}
            />
          </section>
        )}

        {/* SPORTS LIST */}
        <section className="my-panel organizer-sports-panel">
          <div className="my-panel-title">
            <span>🏅</span>
            <div><h3>Available Sports</h3><p>Sports currently available in SportSync</p></div>
          </div>
          <div className="organizer-sports-grid">
            {sports.map((sport) => (
              <div className="organizer-sport-card" key={sport.sport_id}>
                <div className="organizer-sport-icon">{sportIcon(sport.sport_name)}</div>
                <div>
                  <strong>{sport.sport_name}</strong>
                  <span>{sport.session_count} {Number(sport.session_count) === 1 ? "session" : "sessions"}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* SCHEDULE */}
        <section className="my-panels">

          <div className="my-panel" ref={scheduleRef}>
            <div className="my-panel-title">
              <span>📅</span>
              <div>
                <h3>{mode === "update" ? "Update Schedule" : mode === "remove" ? "Remove Schedule" : showAllSessions ? "All Sessions" : "Upcoming Schedule"}</h3>
                <p>{mode === "update" ? "Choose a session to edit" : mode === "remove" ? "Choose a session to delete" : showAllSessions ? "Every session in the database" : "Next scheduled sessions"}</p>
              </div>
            </div>
            <div className="my-list">
              {data && visibleSessions.length === 0 && <p className="loading-note">No sessions found.</p>}
              {mode && (
                <button type="button" className="secondary-btn schedule-mode-done" onClick={stopMode}>✓ Done</button>
              )}
              {visibleSessions.map((s) => (
                <div className={mode ? "my-list-item with-action" : "my-list-item"} key={s.session_id}>
                  <span>{sportIcon(s.sport_name)}</span>
                  <div>
                    <strong>{s.session_name}</strong>
                    <small>{sessionWhen(s)}{s.coach_name ? ` • Coach ${s.coach_name}` : ""}</small>
                  </div>
                  <b>{s.status}</b>
                  {mode === "update" && (
                    <button type="button" className="row-action" onClick={() => editSession(s)}>✏️ Edit</button>
                  )}
                  {mode === "remove" && (
                    <button type="button" className="row-action danger" disabled={removingId === s.session_id} onClick={() => removeSession(s)}>
                      {removingId === s.session_id ? "Removing…" : "🗑️ Remove"}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="my-panel">
            <div className="my-panel-title">
              <span>🗓️</span>
              <div><h3>Schedule Management</h3><p>Organize sports activities</p></div>
            </div>
            <div className="organizer-schedule-actions">
              <button onClick={openSessionForm}>➕ Create Schedule</button>
              <button onClick={viewSchedule}>📅 View Schedule</button>
              <button onClick={startUpdate}>✏️ Update Schedule</button>
              <button onClick={startRemove}>🗑️ Remove Schedule</button>
            </div>
          </div>

        </section>

      </main>

    </div>
  );
}

export default OrganizerDashboard;
