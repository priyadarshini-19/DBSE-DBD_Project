import React, { useEffect, useMemo, useState } from "react";
import { dashboardApi, participantsApi } from "../services-api";
import { fmtDateTime, sessionWhen, sportIcon } from "../utils";

const ACTIONS = [
  { key: "sessions", icon: "📅", label: "View My Sessions" },
  { key: "join", icon: "🏃", label: "Join Session" },
  { key: "performance", icon: "📈", label: "View Performance" },
  { key: "notifications", icon: "🔔", label: "Notifications" },
];

// Sample rows shown (and labelled on screen) only while the database has nothing for this athlete yet
const samplePerformance = (sport) => [
  { performance_id: "sp-1", session_name: `${sport} Practice`, sport_name: sport, remarks: "Great effort and focus", score: 88, duration_minutes: 60 },
  { performance_id: "sp-2", session_name: `${sport} Skills Training`, sport_name: sport, remarks: "Good improvement", score: 82, duration_minutes: 45 },
  { performance_id: "sp-3", session_name: `${sport} Practice Match`, sport_name: sport, remarks: "Work on stamina", score: 76, duration_minutes: 90 },
];
const SAMPLE_NOTIFICATIONS = [
  { notification_id: "sn-1", message: "Welcome to SportSync! Join a session to get started.", notification_date: "2026-10-03 09:00:00", status: "unread" },
  { notification_id: "sn-2", message: "New training sessions have been scheduled this week.", notification_date: "2026-10-02 18:30:00", status: "unread" },
  { notification_id: "sn-3", message: "Your coach will record your performance after each session.", notification_date: "2026-10-01 10:15:00", status: "read" },
];

export default function AthleteDashboard({ user = {}, onBack, onLogout }) {
  const token = localStorage.getItem("sportsyncToken");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  // Which Quick Action panel is open: "sessions" | "join" | "performance" | "notifications" | null
  const [view, setView] = useState("sessions");

  useEffect(() => {
    let alive = true;
    dashboardApi.athlete(token)
      .then((result) => { if (alive) { setData(result); setError(""); } })
      .catch((e) => { if (alive) setError(e.message); });
    return () => { alive = false; };
  }, [token, reloadKey]);

  const sessions = useMemo(() => (data ? data.sessions : []), [data]);
  const available = sessions.filter((s) => s.status === "scheduled" && !s.joined);
  const mine = sessions.filter((s) => s.joined);
  const performance = data ? data.performance : [];
  const notifications = data ? data.notifications : [];
  const stats = data ? data.stats : null;
  const sport = user.sport_preference || user.sport || "Not selected";

  // Fall back to labelled sample rows when the database has none
  const samplePerf = Boolean(data) && performance.length === 0;
  const performanceRows = samplePerf ? samplePerformance(sport === "Not selected" ? "Training" : sport) : performance;
  const sampleNotes = Boolean(data) && notifications.length === 0;
  const notificationRows = sampleNotes ? SAMPLE_NOTIFICATIONS : notifications;

  async function join(id) {
    setBusy(id);
    setNotice("");
    try {
      await participantsApi.join(id, token);
      setNotice("Successfully joined the session.");
      setReloadKey((n) => n + 1);
    } catch (e) {
      setNotice(e.message);
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="my-dashboard-page">
      <header className="my-dashboard-header">
        <button className="my-back-button" onClick={onBack}>← Dashboard</button>
        <div className="my-brand"><h1>SportSync</h1><p>SPORTS & ATHLETICS</p></div>
        <button className="my-logout-button" onClick={onLogout}>Logout</button>
      </header>

      <main className="my-dashboard-content">
        <section className="my-welcome-card">
          <div className="my-profile-icon">🏃</div>
          <div>
            <span className="my-label">MY ATHLETE DASHBOARD</span>
            <h2>Welcome, {user.name || "Athlete"}</h2>
            <p>{sport} Athlete</p>
          </div>
        </section>

        {error && <p className="error-message" role="alert">{error}</p>}
        {notice && <p className="organizer-success" role="status">{notice}</p>}
        {!data && !error && <p className="loading-note">Loading your data from the database…</p>}

        <section className="my-stat-grid">
          <div className="my-stat-card"><div className="my-stat-icon">📅</div><div><span>My Sessions</span><strong>{stats ? stats.sessions_joined : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">🏅</div><div><span>My Sport</span><strong>{sport}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">📈</div><div><span>Performance Records</span><strong>{stats ? stats.performance_records : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">🔔</div><div><span>Unread Notifications</span><strong>{stats ? stats.unread_notifications : "…"}</strong></div></div>
        </section>

        {/* ================= QUICK ACTIONS ================= */}
        <section className="my-actions">
          <h3>Quick Actions</h3>
          <div className="my-action-grid">
            {ACTIONS.map((a) => (
              <button
                key={a.key}
                type="button"
                className={view === a.key ? "active" : ""}
                onClick={() => setView(view === a.key ? null : a.key)}
              >
                <span>{a.icon}</span>{a.label}
              </button>
            ))}
          </div>
        </section>

        {/* ================= DETAILS ================= */}
        {view && (
          <section className="my-panel detail-panel">
            <button type="button" className="detail-close" onClick={() => setView(null)}>← Close</button>

            {view === "sessions" && (
              <>
                <h3 className="detail-title">My Joined Sessions</h3>
                {!data && !error && <p className="loading-note">Loading…</p>}
                {data && mine.length === 0 && <p className="detail-empty">No joined sessions yet.</p>}
                <div className="my-list">
                  {mine.map((s) => (
                    <div className="my-list-item" key={s.session_id}>
                      <span>{sportIcon(s.sport_name)}</span>
                      <div>
                        <strong>{s.session_name}</strong>
                        <small>{sessionWhen(s)}{s.coach_name ? ` • Coach ${s.coach_name}` : ""}</small>
                      </div>
                      <b>{s.attendance || s.status}</b>
                    </div>
                  ))}
                </div>
              </>
            )}

            {view === "join" && (
              <>
                <h3 className="detail-title">Join a Session</h3>
                {!data && !error && <p className="loading-note">Loading…</p>}
                {data && available.length === 0 && <p className="detail-empty">No open sessions right now.</p>}
                <div className="my-list">
                  {available.map((s) => (
                    <div className="my-list-item with-action" key={s.session_id}>
                      <span>{sportIcon(s.sport_name)}</span>
                      <div>
                        <strong>{s.session_name}</strong>
                        <small>{sessionWhen(s)}{s.coach_name ? ` • Coach ${s.coach_name}` : ""}</small>
                      </div>
                      <b>{s.participant_count} joined</b>
                      <button type="button" className="row-action" disabled={busy === s.session_id} onClick={() => join(s.session_id)}>
                        {busy === s.session_id ? "Joining…" : "Join Session"}
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}

            {view === "performance" && (
              <>
                <h3 className="detail-title">
                  My Performance
                  {stats && stats.average_score !== null ? <span className="detail-sub"> • average score {stats.average_score}</span> : null}
                </h3>
                {!data && !error && <p className="loading-note">Loading…</p>}
                {samplePerf && <p className="sample-note">Sample data – shown until your coach records your performance.</p>}
                {performanceRows.length > 0 && (
                  <div className="performance-grid">
                    {performanceRows.map((p) => (
                      <div key={p.performance_id}>
                        <span>{p.session_name || "Session"}{p.sport_name ? ` (${p.sport_name})` : ""}{p.remarks ? ` — ${p.remarks}` : ""}</span>
                        <strong>{p.score ?? "—"}</strong>
                        {p.duration_minutes ? <small>{p.duration_minutes} min</small> : null}
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {view === "notifications" && (
              <>
                <h3 className="detail-title">My Notifications</h3>
                {!data && !error && <p className="loading-note">Loading…</p>}
                {sampleNotes && <p className="sample-note">Sample data – shown until you receive notifications.</p>}
                <div className="my-list">
                  {notificationRows.map((n) => (
                    <div className="my-list-item" key={n.notification_id}>
                      <span>🔔</span>
                      <div>
                        <strong>{n.message}</strong>
                        <small>{fmtDateTime(n.notification_date)}</small>
                      </div>
                      <b>{n.status}</b>
                    </div>
                  ))}
                </div>
              </>
            )}
          </section>
        )}
      </main>
    </div>
  );
}
