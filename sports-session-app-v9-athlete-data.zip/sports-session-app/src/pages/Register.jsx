import React, { useEffect, useState } from "react";
import { authApi, sportsApi } from "../services-api";

function Register({ onRegister, goToLogin }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "",
    sport: "",
  });

  const [message, setMessage] = useState("");

  const [sports, setSports] = useState([
    "Football",
    "Cricket",
    "Basketball",
    "Tennis",
    "Badminton",
    "Athletics",
    "Swimming",
    "Volleyball",
    "Hockey",
    "Table Tennis",
  ]);

  // Load the sports list from the database so new sports appear here automatically
  useEffect(() => {
    let alive = true;
    sportsApi.list()
      .then((rows) => {
        if (alive && Array.isArray(rows) && rows.length) setSports(rows.map((r) => r.sport_name));
      })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  const roles = [
    "Athlete",
    "Coach",
    "Organizer",
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));

    setMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Name, email, password and role are always required
    if (
      !formData.name.trim() ||
      !formData.email.trim() ||
      !formData.password ||
      !formData.confirmPassword ||
      !formData.role
    ) {
      setMessage("Please fill all the required fields.");
      return;
    }

    // Sport is required only for Athlete and Coach
    if (
      (formData.role === "Athlete" ||
        formData.role === "Coach") &&
      !formData.sport
    ) {
      setMessage("Please select your sport.");
      return;
    }

    if (
      formData.password !==
      formData.confirmPassword
    ) {
      setMessage("Passwords do not match.");
      return;
    }

    try {
      const created = await authApi.register({
        name: formData.name.trim(),
        email: formData.email.trim().toLowerCase(),
        password: formData.password,
        role: formData.role.toLowerCase(),
        sport_preference: formData.role === "Organizer" ? null : formData.sport,
      });
      onRegister(created);
    } catch (error) {
      setMessage(error.message || "Registration failed. Please try again.");
    }
  };

  return (
    <div className="auth-page">

      <div className="auth-card register-card">

        <div className="auth-logo">
          🏆
        </div>

        <h1>SportSync</h1>

        <p className="auth-subtitle">
          SPORTS & ATHLETICS
        </p>

        <h2>Create Account</h2>

        <p className="auth-description">
          Join SportSync and manage your sports activities
        </p>

        <form onSubmit={handleSubmit}>

          {/* NAME */}
          <div className="input-group">

            <label>Full Name</label>

            <input
              type="text"
              name="name"
              placeholder="Enter your full name"
              value={formData.name}
              onChange={handleChange}
            />

          </div>


          {/* EMAIL */}
          <div className="input-group">

            <label>Email Address</label>

            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
            />

          </div>


          {/* ROLE */}
          <div className="input-group">

            <label>Select Your Role</label>

            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
            >

              <option value="">
                -- Select Role --
              </option>

              {roles.map((role) => (
                <option
                  key={role}
                  value={role}
                >
                  {role}
                </option>
              ))}

            </select>

          </div>


          {/* SPORT ONLY FOR ATHLETE / COACH */}
          {(formData.role === "Athlete" ||
            formData.role === "Coach") && (

            <div className="input-group">

              <label>Select Your Sport</label>

              <select
                name="sport"
                value={formData.sport}
                onChange={handleChange}
              >

                <option value="">
                  -- Select Sport --
                </option>

                {sports.map((sport) => (
                  <option
                    key={sport}
                    value={sport}
                  >
                    {sport}
                  </option>
                ))}

              </select>

            </div>

          )}


          {/* ORGANIZER INFORMATION */}
          {formData.role === "Organizer" && (

            <div className="organizer-note">

              <span>📋</span>

              <p>
                As an Organizer, you will manage sports
                and organize sports schedules. You do not
                need to select a sport.
              </p>

            </div>

          )}


          {/* PASSWORD */}
          <div className="input-group">

            <label>Password</label>

            <input
              type="password"
              name="password"
              placeholder="Create a password"
              value={formData.password}
              onChange={handleChange}
            />

          </div>


          {/* CONFIRM PASSWORD */}
          <div className="input-group">

            <label>Confirm Password</label>

            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirm your password"
              value={formData.confirmPassword}
              onChange={handleChange}
            />

          </div>


          {/* MESSAGE */}
          {message && (
            <div className="error-message">
              {message}
            </div>
          )}


          {/* REGISTER */}
          <button
            type="submit"
            className="primary-btn"
          >
            CREATE ACCOUNT
          </button>

        </form>


        <div className="auth-footer">

          <span>
            Already have an account?
          </span>

          <button
            type="button"
            className="link-btn"
            onClick={goToLogin}
          >
            Login
          </button>

        </div>

      </div>

    </div>
  );
}

export default Register;