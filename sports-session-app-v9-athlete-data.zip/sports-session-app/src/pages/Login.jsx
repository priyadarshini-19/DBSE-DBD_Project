import React, { useState } from "react";
import { authApi } from "../services-api";

function Login({ onLogin, goToRegister }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    if (!email.trim() || !password) { setMessage("Please enter your email and password."); return; }
    try {
      const result = await authApi.login({ email: email.trim().toLowerCase(), password });
      localStorage.setItem("sportsyncToken", result.access_token);
      const user = { ...result.user, sport: result.user.sport_preference, role: result.user.role.charAt(0).toUpperCase() + result.user.role.slice(1) };
      localStorage.setItem("sportsyncCurrentUser", JSON.stringify(user));
      onLogin(user);
    } catch (error) { setMessage(error.message || "Login failed. Check the backend connection."); }
  };

  return (
    <div className="auth-page">

      <div className="auth-card">

        {/* LOGO */}
        <div className="auth-logo">
          🏆
        </div>

        {/* TITLE */}
        <h1>
          SportSync
        </h1>

        <p className="auth-subtitle">
          SPORTS & ATHLETICS
        </p>

        <h2>
          Welcome Back
        </h2>

        <p className="auth-description">
          Login to your SportSync account
        </p>

        {/* LOGIN FORM */}
        <form onSubmit={handleSubmit}>

          {/* EMAIL */}
          <div className="input-group">

            <label>
              Email Address
            </label>

            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setMessage("");
              }}
            />

          </div>


          {/* PASSWORD */}
          <div className="input-group">

            <label>
              Password
            </label>

            <input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setMessage("");
              }}
            />

          </div>


          {/* ERROR */}
          {message && (
            <div className="error-message">
              {message}
            </div>
          )}


          {/* LOGIN BUTTON */}
          <button
            type="submit"
            className="primary-btn"
          >
            LOGIN
          </button>

        </form>


        {/* REGISTER */}
        <div className="auth-footer">

          <span>
            Don't have an account?
          </span>

          <button
            type="button"
            className="link-btn"
            onClick={goToRegister}
          >
            Register
          </button>

        </div>

      </div>

    </div>
  );
}

export default Login;