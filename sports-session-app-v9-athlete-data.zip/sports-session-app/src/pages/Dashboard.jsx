import React, { useEffect, useState } from "react";
import { dashboardApi, tablesApi } from "../services-api";
import { fmtDate, fmtTime, fmtDateTime } from "../utils";

const TABLE_NAMES = [
  "Users", "Sports", "Coaches", "Sessions",
  "Session_Participants", "Performance", "Notifications", "AuthLogs",
];

const TABLE_ICONS = {
  Users: "👥", Sports: "🏅", Coaches: "👨‍🏫", Sessions: "📅",
  Session_Participants: "👤", Performance: "📈", Notifications: "🔔", AuthLogs: "🔐",
};

const ROLE_ICONS = { coach: "👨‍🏫", athlete: "🏃", organizer: "📋", admin: "🛡️" };

function formatCell(column, value) {
  if (value === null || value === undefined || value === "") return "—";
  if (column === "session_date") return fmtDate(value);
  if (column === "session_time") return fmtTime(value);
  if (column === "notification_date" || column === "login_time") return fmtDateTime(value);
  return String(value);
}

function Dashboard({ user, onLogout, onOpenMyDashboard }) {
  const token = localStorage.getItem("sportsyncToken");
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedTable, setSelectedTable] = useState(null);

  const [summary, setSummary] = useState(null);
  const [summaryError, setSummaryError] = useState("");

  const [tableData, setTableData] = useState(null);
  const [tableError, setTableError] = useState("");
  const [tableLoading, setTableLoading] = useState(false);

  const role = (user.role || "").toLowerCase();
  const sport = user.sport_preference || user.sport || "";

  // Overview numbers come straight from MySQL
  useEffect(() => {
    let alive = true;
    dashboardApi.summary(token)
      .then((data) => { if (alive) setSummary(data); })
      .catch((error) => { if (alive) setSummaryError(error.message); });
    return () => { alive = false; };
  }, [token]);

  // Load the selected table from MySQL
  useEffect(() => {
    if (!selectedTable) return undefined;
    let alive = true;
    setTableLoading(true);
    setTableError("");
    setTableData(null);
    tablesApi.get(selectedTable, token)
      .then((data) => { if (alive) setTableData(data); })
      .catch((error) => { if (alive) setTableError(error.message); })
      .finally(() => { if (alive) setTableLoading(false); });
    return () => { alive = false; };
  }, [selectedTable, token]);

  const count = (key) => (summary ? summary[key] : "…");

  const formattedDate = new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  const openTable = (tableName) => {
    setSelectedTable(tableName);
    setMenuOpen(false);
  };

  return (
    <div className="dashboard-page">

      {/* ================= HEADER ================= */}
      <header className="dashboard-header">

        <div className="dashboard-left">
          <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)}>
            ☰
          </button>

          {menuOpen && (
            <div className="side-menu">

              <div className="menu-section-title">MY SPORTSYNC</div>

              <button className="menu-item my-dashboard-item" onClick={onOpenMyDashboard}>
                {ROLE_ICONS[role] || "🏆"}
                <span>My {user.role} Dashboard</span>
              </button>

              <div className="menu-section-title">APPLICATION TABLES</div>

              {TABLE_NAMES.map((tableName) => (
                <button key={tableName} className="menu-item" onClick={() => openTable(tableName)}>
                  <span className="menu-icon">{TABLE_ICONS[tableName]}</span>
                  <span>{tableName}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="brand-heading">
          <h1>SportSync</h1>
          <p>SPORTS & ATHLETICS</p>
        </div>

        <div className="dashboard-right">
          <div className="user-info">
            <strong>{user.name}</strong>
            <span>{user.role}</span>
            {sport && <span>{sport}</span>}
          </div>

          <button className="logout-button" onClick={onLogout}>
            Logout
          </button>
        </div>

      </header>

      <div className="dashboard-date">{formattedDate}</div>

      {!selectedTable ? (

        <main className="dashboard-content">

          <section className="welcome-board">
            <span className="welcome-label">SPORTS MANAGEMENT</span>
            <h2>Welcome to SportSync</h2>
            <p>
              Manage matches, sessions, athletes and performance from one platform.
            </p>
          </section>

          {summaryError && (
            <p className="error-message" role="alert">{summaryError}</p>
          )}

          <section className="stats-grid">

            <div className="stat-card">
              <div className="stat-icon">👥</div>
              <div className="stat-content">
                <span>Total Users</span>
                <strong>{count("users")}</strong>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-icon">🏅</div>
              <div className="stat-content">
                <span>Sports</span>
                <strong>{count("sports")}</strong>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-icon">📅</div>
              <div className="stat-content">
                <span>Sessions</span>
                <strong>{count("sessions")}</strong>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-icon">📈</div>
              <div className="stat-content">
                <span>Performance</span>
                <strong>{count("performance")}</strong>
              </div>
            </div>

          </section>

          <section className="dashboard-info">

            <div className="info-box">
              <div className="info-icon">🏅</div>
              <div>
                <span>Your Sport</span>
                <strong>{sport || "Not selected"}</strong>
              </div>
            </div>

            <div className="info-box">
              <div className="info-icon">👤</div>
              <div>
                <span>Your Role</span>
                <strong>{user.role}</strong>
              </div>
            </div>

            <div className="info-box">
              <div className="info-icon">📅</div>
              <div>
                <span>Sessions Available</span>
                <strong>{count("sessions")}</strong>
              </div>
            </div>

          </section>

          <section className="quick-section">
            <div className="quick-card">
              <span>🏆</span>
              <div>
                <h3>Welcome, {user.name}</h3>
                <p>
                  Your SportSync account is ready. Explore sessions, performance and
                  sports activities.
                </p>
              </div>
            </div>
          </section>

        </main>

      ) : (

        <main className="table-page">

          <button className="back-dashboard-button" onClick={() => setSelectedTable(null)}>
            ← Back to Dashboard
          </button>

          <div className="table-heading">
            <div>
              <span>SPORTSYNC DATABASE</span>
              <h2>{selectedTable}</h2>
            </div>
            <p>
              {tableData
                ? tableData.shown < tableData.total
                  ? `Showing ${tableData.shown} of ${tableData.total} records`
                  : `${tableData.total} records`
                : ""}
            </p>
          </div>

          {tableLoading && <p className="loading-note">Loading {selectedTable} from the database…</p>}

          {tableError && <p className="error-message" role="alert">{tableError}</p>}

          {tableData && tableData.scope === "own" && (
            <p className="scope-note">Showing only the records that belong to you.</p>
          )}

          {tableData && tableData.rows.length === 0 && !tableLoading && (
            <p className="loading-note">No records found in this table.</p>
          )}

          {tableData && tableData.rows.length > 0 && (
            <div className="data-table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    {tableData.columns.map((column) => (
                      <th key={column}>{column.replace(/_/g, " ")}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tableData.rows.map((row, index) => (
                    <tr key={index}>
                      {tableData.columns.map((column) => (
                        <td key={column}>{formatCell(column, row[column])}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

        </main>

      )}

    </div>
  );
}

export default Dashboard;
