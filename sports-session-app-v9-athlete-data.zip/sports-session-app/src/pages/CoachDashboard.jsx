import React, { useEffect, useState } from "react";
import { dashboardApi } from "../services-api";
import { sessionWhen, sportIcon } from "../utils";

// Shown in "All My Sessions" only when the database has no sessions for this coach yet.
const sampleAllSessions = (sport) => [
  { session_id: "sample-1", session_name: `${sport} Fitness Training`, sport_name: sport, session_date: "2026-10-12", session_time: "06:30:00", location: "Main Ground", status: "scheduled", participant_count: 12 },
  { session_id: "sample-2", session_name: `${sport} Skills Practice`, sport_name: sport, session_date: "2026-10-14", session_time: "16:00:00", location: "Practice Area", status: "scheduled", participant_count: 8 },
  { session_id: "sample-3", session_name: `${sport} Team Strategy Meeting`, sport_name: sport, session_date: "2026-10-01", session_time: "17:30:00", location: "Club House", status: "completed", participant_count: 15 },
];

// Sample rows for panels that are empty in the database (clearly labelled on screen)
const sampleUpcoming = (sport) => [
  { session_id: "up-1", session_name: `${sport} Practice`, sport_name: sport, session_date: "2026-10-10", session_time: "17:00:00", location: "Main Ground", status: "scheduled", participant_count: 10 },
  { session_id: "up-2", session_name: `${sport} Skills Training`, sport_name: sport, session_date: "2026-10-13", session_time: "06:30:00", location: "Practice Area", status: "scheduled", participant_count: 8 },
  { session_id: "up-3", session_name: `${sport} Practice Match`, sport_name: sport, session_date: "2026-10-17", session_time: "16:00:00", location: "Stadium", status: "scheduled", participant_count: 14 },
];
const SAMPLE_PERFORMANCE = [
  { performance_id: "pf-1", athlete: "Aditya Singh", session_name: "Practice Session", remarks: "Excellent teamwork", score: 92 },
  { performance_id: "pf-2", athlete: "Riya Sharma", session_name: "Skills Training", remarks: "Good progress", score: 85 },
  { performance_id: "pf-3", athlete: "Arjun Reddy", session_name: "Practice Match", remarks: "Needs more stamina", score: 78 },
];

function CoachDashboard({ user, onBack, onLogout }) {
  const token = localStorage.getItem("sportsyncToken");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    dashboardApi.coach(token)
      .then((result) => { if (alive) { setData(result); setError(""); } })
      .catch((e) => { if (alive) setError(e.message); });
    return () => { alive = false; };
  }, [token]);

  const coach = data ? data.coach : null;
  const sessions = data ? data.sessions : [];
  const athletes = data ? data.athletes : [];
  const performance = data ? data.performance : [];
  const stats = data ? data.stats : null;
  const sport = (coach && coach.sport_name) || user.sport_preference || user.sport || "Not selected";

  const upcoming = sessions
    .filter((s) => s.status === "scheduled")
    .sort((a, b) => String(a.session_date || "").localeCompare(String(b.session_date || "")));

  const sampleUp = Boolean(data) && upcoming.length === 0;
  const upcomingRows = sampleUp ? sampleUpcoming(sport === "Not selected" ? "Training" : sport) : upcoming;
  const samplePerf = Boolean(data) && performance.length === 0;
  const performanceRows = samplePerf ? SAMPLE_PERFORMANCE : performance;

  // All sessions this coach is part of; sample rows only if there are none in the database
  const usingSample = Boolean(data) && sessions.length === 0;
  const sampleSport = sport === "Not selected" ? "Training" : sport;
  const allSessions = usingSample ? sampleAllSessions(sampleSport) : sessions;

  return (
    <div className="my-dashboard-page">

      <header className="my-dashboard-header">
        <button className="my-back-button" onClick={onBack}>← Dashboard</button>
        <div className="my-brand"><h1>SportSync</h1><p>SPORTS & ATHLETICS</p></div>
        <button className="my-logout-button" onClick={onLogout}>Logout</button>
      </header>

      <main className="my-dashboard-content">

        <section className="my-welcome-card">
          <div className="my-profile-icon">👨‍🏫</div>
          <div>
            <span className="my-label">MY COACH DASHBOARD</span>
            <h2>Welcome, Coach {user.name}</h2>
            <p>{sport} Coach</p>
          </div>
        </section>

        {error && <p className="error-message" role="alert">{error}</p>}
        {!data && !error && <p className="loading-note">Loading your data from the database…</p>}
        {data && !coach && (
          <p className="organizer-error" role="alert">
            Your account ({user.email}) is not linked to a coach profile, so there are no sessions to show.
            Ask an organizer to add a coach with this email address.
          </p>
        )}

        <section className="my-stat-grid">
          <div className="my-stat-card"><div className="my-stat-icon">👥</div><div><span>My Athletes</span><strong>{stats ? stats.athletes : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">📅</div><div><span>Sessions</span><strong>{stats ? stats.sessions : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">📈</div><div><span>Performance Records</span><strong>{stats ? stats.performance_records : "…"}</strong></div></div>
          <div className="my-stat-card"><div className="my-stat-icon">🏅</div><div><span>My Sport</span><strong>{sport}</strong></div></div>
        </section>

        <section className="my-panels">

          {/* MY ATHLETES */}
          <div className="my-panel">
            <div className="my-panel-title"><span>👥</span><div><h3>My Athletes</h3><p>{sport !== "Not selected" ? `${sport} athletes` : "Athletes who joined your sessions"}</p></div></div>
            <div className="my-list scroll-list">
              {data && athletes.length === 0 && <p className="loading-note">{sport !== "Not selected" ? `No ${sport} athletes are registered yet.` : "No athletes have joined your sessions yet."}</p>}
              {athletes.map((a) => (
                <div className="my-list-item" key={a.user_id}>
                  <span>🏃</span>
                  <div>
                    <strong>{a.name}</strong>
                    <small>{a.sport_preference || "—"}</small>
                  </div>
                  <b>{a.sessions_joined} {Number(a.sessions_joined) === 1 ? "session" : "sessions"}</b>
                </div>
              ))}
            </div>
          </div>

          {/* UPCOMING SESSIONS */}
          <div className="my-panel">
            <div className="my-panel-title"><span>📅</span><div><h3>Upcoming Sessions</h3><p>{sampleUp ? "Sample data – shown until you schedule sessions" : "Your scheduled coaching sessions"}</p></div></div>
            <div className="my-list scroll-list">
              {upcomingRows.map((s) => (
                <div className="my-list-item" key={s.session_id}>
                  <span>{sportIcon(s.sport_name)}</span>
                  <div>
                    <strong>{s.session_name}</strong>
                    <small>{sessionWhen(s)}</small>
                  </div>
                  <b>{s.participant_count} joined</b>
                </div>
              ))}
            </div>
          </div>

          {/* PERFORMANCE RECORDS */}
          <div className="my-panel">
            <div className="my-panel-title"><span>📈</span><div><h3>Performance Records</h3><p>{samplePerf ? "Sample data – shown until results are recorded" : "Results recorded in your sessions"}</p></div></div>
            <div className="my-list scroll-list">
              {performanceRows.map((p) => (
                <div className="my-list-item" key={p.performance_id}>
                  <span>📈</span>
                  <div>
                    <strong>{p.athlete || "Athlete"}</strong>
                    <small>{p.session_name}{p.remarks ? ` • ${p.remarks}` : ""}</small>
                  </div>
                  <b>{p.score ?? "—"}</b>
                </div>
              ))}
            </div>
          </div>

          {/* ALL MY SESSIONS */}
          <div className="my-panel">
            <div className="my-panel-title">
              <span>🗂️</span>
              <div>
                <h3>All My Sessions</h3>
                <p>{usingSample ? "Sample data – shown until you have sessions" : "Every session you are part of"}</p>
              </div>
            </div>
            <div className="my-list scroll-list">
              {allSessions.map((s) => (
                <div className="my-list-item" key={s.session_id}>
                  <span>{sportIcon(s.sport_name)}</span>
                  <div>
                    <strong>{s.session_name}</strong>
                    <small>{sessionWhen(s)}</small>
                  </div>
                  <b>{s.status}</b>
                </div>
              ))}
            </div>
          </div>

        </section>

      </main>

    </div>
  );
}

export default CoachDashboard;
