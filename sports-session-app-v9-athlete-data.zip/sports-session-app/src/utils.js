const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// "2026-09-01" -> "01 Sep 2026"
export function fmtDate(value) {
  if (!value) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value));
  if (!m) return String(value);
  return `${m[3]} ${MONTHS[Number(m[2]) - 1]} ${m[1]}`;
}

// "16:30:00" -> "4:30 PM"
export function fmtTime(value) {
  if (!value) return "";
  const m = /^(\d{1,2}):(\d{2})/.exec(String(value));
  if (!m) return String(value);
  const hour = Number(m[1]);
  return `${hour % 12 || 12}:${m[2]} ${hour >= 12 ? "PM" : "AM"}`;
}

// "2026-09-01 18:00:00" -> "01 Sep 2026, 6:00 PM"
export function fmtDateTime(value) {
  if (!value) return "";
  const [d, t] = String(value).split(/[ T]/);
  return [fmtDate(d), fmtTime(t)].filter(Boolean).join(", ");
}

export function todayISO() {
  return new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD in local time
}

const ICONS = {
  cricket: "🏏", football: "⚽", basketball: "🏀", tennis: "🎾", badminton: "🏸",
  athletics: "🏃", swimming: "🏊", volleyball: "🏐", hockey: "🏑", "table tennis": "🏓",
};
export function sportIcon(name) {
  return ICONS[String(name || "").toLowerCase()] || "🏅";
}

export function capitalize(value) {
  const s = String(value || "");
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// "when / where" line used in session lists
export function sessionWhen(s) {
  return [fmtDate(s.session_date), fmtTime(s.session_time), s.location].filter(Boolean).join(" • ") || "Schedule to be announced";
}
