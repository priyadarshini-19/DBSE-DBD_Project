# SportSync full-stack starter

## Structure
- `src/` is your original React UI; `src/services-api.js` is the shared REST client.
- `backend/app/routers/auth.py`: authentication service (register/login/profile).
- `backend/app/routers/catalog.py`: sports and session service endpoints.
- `backend/app/models.py`: SQLAlchemy mapping to supplied MySQL tables.
- `postman/SportSync.postman_collection.json`: import into Postman.
- `database/original_schema.sql`: original supplied SQL. Use the migration notes below before loading legacy sample data.

## MySQL setup
1. Create database `Match_Sports_Session` in MySQL.
2. Run `database/original_schema.sql` only on a fresh database. Its demo password values are plaintext and must not be used for login; create a new account via `/api/auth/register` instead.
3. For auto-generated IDs and unique email, execute `database/migration.sql` after reviewing it against your existing data. Back up first.

## Backend run (Windows PowerShell)
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# Edit .env with your MySQL password and a strong JWT_SECRET
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000/docs`; `GET /api/health` checks MySQL connectivity.

## Frontend
In project root, create `.env` from `.env.example`, then `npm install` and `npm run dev`.
Use `authApi.login/register`, `sportsApi.list/create/sessions` from `src/services-api.js` in the existing page handlers. Login response shape is `{access_token, token_type, user}`; send token as Bearer for protected endpoints. Do not treat localStorage as authoritative authentication.

## API verification
Import the Postman collection. Run Health, Register (once), Login, My profile, List sports, List sessions. A repeated registration returns 409 by design. For a sport creation request use organizer/admin token.

## Scope note
This is a modular monolith demonstrating service boundaries, not independently deployed microservices. JWT is a basic access-token implementation; production deployment should use HTTPS, secret management, refresh-token rotation, rate limits, migrations, and stronger role/ownership checks.

## Dashboard data endpoints (all read from MySQL)
| Endpoint | Who | Returns |
|---|---|---|
| `GET /api/dashboard/summary` | any signed-in user | row counts for the home dashboard |
| `GET /api/dashboard/athlete` | athlete | sessions (with `joined`), own performance, notifications, stats |
| `GET /api/dashboard/coach` | coach | coach profile (linked by email), sessions, athletes, performance |
| `GET /api/dashboard/organizer` | organizer/admin | sports with session counts, all sessions, coaches, stats |
| `GET /api/tables/{name}` | any signed-in user | table browser; all rows for every user by default (`TABLE_VIEW_SCOPE=all`); set `TABLE_VIEW_SCOPE=own` to scope non-organizers to their own rows |
| `GET /api/coaches` | any signed-in user | coaches with sport |
| `POST /api/sessions` | coach/organizer/admin | create a session (coaches are always assigned to themselves) |
| `PUT /api/sessions/{id}` | organizer/admin (coach: own sessions) | update any of name, sport, coach, date, time, location, status |
| `DELETE /api/sessions/{id}` | organizer/admin (coach: own sessions) | remove a session together with its participant and performance rows |

SQL lives in `backend/app/queries.py`; `password_hash` is never returned. Login attempts are written to `AuthLogs`.
Run `python prepare_database.py` once after loading the SQL (see RUN_IN_VSCODE.md).

## Changes in this version
- `JWT_SECRET` is now mandatory (32+ chars, not the placeholder); the API refuses to start otherwise.
- Public registration allows `athlete`, `coach`, `organizer` only. Create `admin` users directly in MySQL.
- `GET /api/users` requires an organizer or admin token.
- Legacy plaintext passwords from the sample SQL return 401 on login instead of crashing; register a new account to log in.
- `bcrypt==4.0.1` is pinned for compatibility with `passlib==1.7.4`.
- Read endpoints in `records.py` now return a 500 with a log entry on real database errors instead of an empty list.
- The frontend clears the session and returns to login when the token expires (401).
- New: dashboards read live MySQL data; `backend/prepare_database.py`, `app/queries.py` and `app/routers/dashboard.py` added.
- Registering as a coach also creates a row in `Coaches` (linked by email); logins are recorded in `AuthLogs`.
- The Organizer "Add Sport" form no longer has a category field because the `Sports` table has no category column.

## Changes in v1.2
- Athlete dashboard: Quick Actions (View My Sessions, Join Session, View Performance, Notifications) each open their own detail panel with a Close button.
- Organizer dashboard: Update Schedule and Remove Schedule now work (new `PUT` / `DELETE /api/sessions/{id}`).
- Coach dashboard: a coach login without a row in `Coaches` is linked automatically; the sports list can no longer blank the dashboard.
- Unexpected server crashes now return a JSON error (with CORS headers) and a traceback in the backend terminal, instead of the browser showing "Cannot connect to the API".

## v1.2.1
- On start-up the API now sets every ID column to `AUTO_INCREMENT` if it isn't already (`ensure_auto_increment()` in `app/database.py`). This fixes `Field 'log_id' / 'session_id' doesn't have a default value` when logging in or creating a session on a database where `prepare_database.py` was never run. Set `AUTO_PREPARE_DB=false` in `backend/.env` to turn it off.
- `python prepare_database.py` is still worth running once: it also hashes sample passwords, adds unique keys and creates coach logins.

## v1.2.2 (UI)
- Organizer dashboard: the bottom "Organizer Actions" block was removed; Schedule Management (Create / View / Update / Remove) remains.
- Coach dashboard: shows My Athletes, Upcoming Sessions, Performance Records and All My Sessions. If the coach has no sessions yet, All My Sessions shows labelled sample data.

## v1.2.3
- Coach dashboard "My Athletes" now lists every athlete registered for the coach's own sport (`COACH_SPORT_ATHLETES` in `queries.py`), not only athletes who joined his sessions.
- Upcoming Sessions, Performance Records and All My Sessions show labelled sample data (in the coach's sport) while the database has none.

## v1.2.4
- Athlete dashboard: View Performance and Notifications show labelled sample data while the athlete has no records in the database.
