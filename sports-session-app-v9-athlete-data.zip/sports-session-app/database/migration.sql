USE Match_Sports_Session;
-- Back up first. If sample IDs already exist, do not blindly re-run the original INSERT statements.
ALTER TABLE Users MODIFY user_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE Users MODIFY name VARCHAR(100) NOT NULL;
ALTER TABLE Users MODIFY email VARCHAR(100) NOT NULL;
ALTER TABLE Users MODIFY password_hash VARCHAR(255) NOT NULL;
ALTER TABLE Users ADD UNIQUE KEY uq_users_email (email);
ALTER TABLE Sports MODIFY sport_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE Sports MODIFY sport_name VARCHAR(50) NOT NULL;
ALTER TABLE Sports ADD UNIQUE KEY uq_sports_name (sport_name);
ALTER TABLE Coaches MODIFY coach_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE Sessions MODIFY session_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE Session_Participants MODIFY participant_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE Performance MODIFY performance_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE Notifications MODIFY notification_id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE AuthLogs MODIFY log_id INT NOT NULL AUTO_INCREMENT;
-- Normalize legacy role values for API role checks.
UPDATE Users SET role=LOWER(role);
