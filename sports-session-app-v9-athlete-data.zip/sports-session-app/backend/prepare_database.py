"""One-time (re-runnable) preparation of the Match_Sports_Session database for the API.

Run from the backend folder with the virtual environment active:
    python prepare_database.py

It is safe to run more than once. It will:
  1. make every table's ID column AUTO_INCREMENT (needed so new rows can be inserted),
  2. add UNIQUE keys on Users.email and Sports.sport_name,
  3. lower-case Users.role,
  4. replace plaintext passwords from the sample data (e.g. 'demo123') with bcrypt hashes,
     so the sample users can log in with their original password,
  5. create a login for each row in Coaches (role 'coach', same email, password 'demo123')
     so the Coach dashboard has data to show. Skip this with --skip-coach-users.
The sample password 'demo123' is for local demos only. Change it before sharing the database.
"""
import argparse
import sys
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from passlib.context import CryptContext
from app.database import engine

DEMO_PASSWORD = "demo123"
PK = {"Users": "user_id", "Sports": "sport_id", "Coaches": "coach_id", "Sessions": "session_id",
      "Session_Participants": "participant_id", "Performance": "performance_id",
      "Notifications": "notification_id", "AuthLogs": "log_id"}
UNIQUE = [("Users", "email", "uq_users_email"), ("Sports", "sport_name", "uq_sports_name")]
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


def step(msg): print(f"\n== {msg}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-coach-users", action="store_true", help="do not create logins for the Coaches table")
    args = ap.parse_args()

    try:
        with engine.connect() as c:
            db = c.execute(text("SELECT DATABASE()")).scalar()
    except SQLAlchemyError as exc:
        print(f"Cannot connect to MySQL: {exc.__class__.__name__}. Check DATABASE_URL in backend/.env and that MySQL is running.")
        sys.exit(1)
    print(f"Connected to database: {db}")

    with engine.begin() as c:
        existing = {r[0].lower(): r[0] for r in c.execute(text(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE()"))}
        missing = [t for t in PK if t.lower() not in existing]
        if missing:
            print("Missing tables:", ", ".join(missing), "- run database/original_schema.sql first.")
            sys.exit(1)

        step("1. AUTO_INCREMENT on ID columns")
        for table, col in PK.items():
            extra = c.execute(text(
                "SELECT extra FROM information_schema.columns WHERE table_schema = DATABASE() "
                "AND LOWER(table_name) = LOWER(:t) AND LOWER(column_name) = LOWER(:c)"), {"t": table, "c": col}).scalar()
            if extra and "auto_increment" in extra.lower():
                print(f"  {table}.{col}: already auto-increment")
            else:
                c.execute(text(f"ALTER TABLE `{existing[table.lower()]}` MODIFY `{col}` INT NOT NULL AUTO_INCREMENT"))
                print(f"  {table}.{col}: set to AUTO_INCREMENT")

    step("2. Unique keys")
    for table, col, name in UNIQUE:
        with engine.begin() as c:
            has = c.execute(text(
                "SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() "
                "AND LOWER(table_name) = LOWER(:t) AND LOWER(column_name) = LOWER(:c) AND non_unique = 0"),
                {"t": table, "c": col}).scalar()
            if has:
                print(f"  {table}.{col}: already unique")
                continue
            try:
                c.execute(text(f"ALTER TABLE `{table}` ADD UNIQUE KEY `{name}` (`{col}`)"))
                print(f"  {table}.{col}: unique key added")
            except SQLAlchemyError:
                print(f"  {table}.{col}: could NOT add unique key (duplicate values exist?) - fix the data and re-run")

    with engine.begin() as c:
        step("3. Roles")
        c.execute(text("UPDATE Users SET role = LOWER(role) WHERE role IS NOT NULL"))
        print("  roles lower-cased")

        step("4. Password hashing")
        rows = c.execute(text("SELECT user_id, password_hash FROM Users")).all()
        todo = [(uid, h) for uid, h in rows if h and not h.startswith("$2")]
        for n, (uid, plain) in enumerate(todo, 1):
            c.execute(text("UPDATE Users SET password_hash = :h WHERE user_id = :i"),
                      {"h": pwd.hash(plain), "i": uid})
            if n % 20 == 0:
                print(f"  hashed {n}/{len(todo)}")
        print(f"  {len(todo)} plaintext password(s) hashed, {len(rows) - len(todo)} already hashed or empty")

        if not args.skip_coach_users:
            step("5. Coach logins")
            coaches = c.execute(text(
                "SELECT co.coach_name, co.email, sp.sport_name FROM Coaches co "
                "LEFT JOIN Sports sp ON sp.sport_id = co.sport_id WHERE co.email IS NOT NULL")).all()
            created = 0
            for name, email, sport in coaches:
                exists = c.execute(text("SELECT 1 FROM Users WHERE LOWER(email) = LOWER(:e)"), {"e": email}).first()
                if exists:
                    continue
                c.execute(text("INSERT INTO Users (name, email, password_hash, role, sport_preference) "
                               "VALUES (:n, :e, :h, 'coach', :s)"),
                          {"n": name, "e": email.lower(), "h": pwd.hash(DEMO_PASSWORD), "s": sport})
                created += 1
            print(f"  {created} coach login(s) created (password: {DEMO_PASSWORD})")

    print("\nDone. Start the API with:  uvicorn app.main:app --reload")


if __name__ == "__main__":
    main()
