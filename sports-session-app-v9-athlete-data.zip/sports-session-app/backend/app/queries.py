"""All SQL used by the dashboard endpoints.

Kept free of framework imports so every statement can be tested against any SQL engine.
Only fixed strings live here; user input is always passed as bound parameters (:uid, :cid, :email).
"""

SUMMARY = """
SELECT
  (SELECT COUNT(*) FROM Users)                AS users,
  (SELECT COUNT(*) FROM Sports)               AS sports,
  (SELECT COUNT(*) FROM Coaches)              AS coaches,
  (SELECT COUNT(*) FROM Sessions)             AS sessions,
  (SELECT COUNT(*) FROM Session_Participants) AS participants,
  (SELECT COUNT(*) FROM Performance)          AS performance,
  (SELECT COUNT(*) FROM Notifications)        AS notifications,
  (SELECT COUNT(*) FROM AuthLogs)             AS auth_logs
"""

SESSION_SELECT = """
SELECT se.session_id, se.session_name, se.sport_id, sp.sport_name,
       se.coach_id, co.coach_name, se.session_date, se.session_time,
       se.location, se.status,
       (SELECT COUNT(*) FROM Session_Participants p WHERE p.session_id = se.session_id) AS participant_count
FROM Sessions se
LEFT JOIN Sports  sp ON sp.sport_id = se.sport_id
LEFT JOIN Coaches co ON co.coach_id = se.coach_id
"""
SESSION_ORDER = " ORDER BY se.session_date DESC, se.session_id DESC"

COACHES = """
SELECT co.coach_id, co.coach_name, co.email, co.sport_id, sp.sport_name
FROM Coaches co
LEFT JOIN Sports sp ON sp.sport_id = co.sport_id
ORDER BY co.coach_name
"""

COACH_BY_EMAIL = """
SELECT co.coach_id, co.coach_name, co.email, co.sport_id, sp.sport_name
FROM Coaches co
LEFT JOIN Sports sp ON sp.sport_id = co.sport_id
WHERE LOWER(co.email) = LOWER(:email)
"""

# ---- athlete ---------------------------------------------------------------
MY_PARTICIPATIONS = """
SELECT participant_id, session_id, attendance
FROM Session_Participants WHERE user_id = :uid
"""

MY_PERFORMANCE = """
SELECT pf.performance_id, pf.session_id, se.session_name, sp.sport_name,
       pf.score, pf.duration_minutes, pf.remarks
FROM Performance pf
LEFT JOIN Sessions se ON se.session_id = pf.session_id
LEFT JOIN Sports   sp ON sp.sport_id = se.sport_id
WHERE pf.user_id = :uid
ORDER BY pf.performance_id DESC
"""

MY_NOTIFICATIONS = """
SELECT notification_id, message, notification_date, status
FROM Notifications WHERE user_id = :uid
ORDER BY notification_id DESC
"""

# ---- coach -----------------------------------------------------------------
COACH_ATHLETES = """
SELECT u.user_id, u.name, u.email, u.sport_preference,
       COUNT(p.participant_id) AS sessions_joined
FROM Session_Participants p
JOIN Sessions se ON se.session_id = p.session_id
JOIN Users u     ON u.user_id = p.user_id
WHERE se.coach_id = :cid
GROUP BY u.user_id, u.name, u.email, u.sport_preference
ORDER BY u.name
"""

# Every athlete registered for the coach's own sport (not only those who joined his sessions)
COACH_SPORT_ATHLETES = """
SELECT u.user_id, u.name, u.email, u.sport_preference,
       (SELECT COUNT(*) FROM Session_Participants p
          JOIN Sessions se ON se.session_id = p.session_id
         WHERE p.user_id = u.user_id AND se.coach_id = :cid) AS sessions_joined
FROM Users u
WHERE LOWER(u.role) = 'athlete' AND LOWER(u.sport_preference) = LOWER(:sport)
ORDER BY u.name
"""

COACH_PERFORMANCE = """
SELECT pf.performance_id, pf.user_id, u.name AS athlete, pf.session_id, se.session_name,
       pf.score, pf.duration_minutes, pf.remarks
FROM Performance pf
JOIN Sessions se ON se.session_id = pf.session_id
LEFT JOIN Users u ON u.user_id = pf.user_id
WHERE se.coach_id = :cid
ORDER BY pf.performance_id DESC
"""

# ---- organizer -------------------------------------------------------------
SPORTS_WITH_COUNTS = """
SELECT sp.sport_id, sp.sport_name, COUNT(se.session_id) AS session_count
FROM Sports sp
LEFT JOIN Sessions se ON se.sport_id = sp.sport_id
GROUP BY sp.sport_id, sp.sport_name
ORDER BY sp.sport_id
"""

ORGANIZER_STATS = """
SELECT
  (SELECT COUNT(*) FROM Sports)                                   AS sports,
  (SELECT COUNT(*) FROM Sessions WHERE status = 'scheduled')      AS scheduled_sessions,
  (SELECT COUNT(*) FROM Sessions WHERE status = 'completed')      AS completed_sessions,
  (SELECT COUNT(*) FROM Session_Participants)                     AS participants,
  (SELECT COUNT(*) FROM Users WHERE role = 'athlete')             AS athletes,
  (SELECT COUNT(*) FROM Coaches)                                  AS coaches
"""

# ---- generic table browser (Application Tables menu) -------------------------
# select/order are fixed; "own" = extra WHERE for athletes (and anyone not organizer/admin),
# "coach" = extra WHERE for coaches. A table without "own" is readable by every signed-in user.
_COACH_SESSIONS = "(SELECT s.session_id FROM Sessions s WHERE s.coach_id = :cid)"

TABLES = {
    "Users": {
        "select": "SELECT u.user_id, u.name, u.email, u.role, u.sport_preference FROM Users u",
        "order": "u.user_id",
        "own": "u.user_id = :uid",
        "coach": ("(u.user_id = :uid OR u.user_id IN (SELECT p.user_id FROM Session_Participants p "
                  "WHERE p.session_id IN " + _COACH_SESSIONS + "))"),
    },
    "Sports": {
        "select": "SELECT sp.sport_id, sp.sport_name FROM Sports sp",
        "order": "sp.sport_id",
    },
    "Coaches": {
        "select": ("SELECT co.coach_id, co.coach_name, co.email, sp.sport_name AS sport "
                   "FROM Coaches co LEFT JOIN Sports sp ON sp.sport_id = co.sport_id"),
        "order": "co.coach_id",
    },
    "Sessions": {
        "select": ("SELECT se.session_id, se.session_name, sp.sport_name AS sport, co.coach_name AS coach, "
                   "se.session_date, se.session_time, se.location, se.status FROM Sessions se "
                   "LEFT JOIN Sports sp ON sp.sport_id = se.sport_id "
                   "LEFT JOIN Coaches co ON co.coach_id = se.coach_id"),
        "order": "se.session_id",
    },
    "Session_Participants": {
        "select": ("SELECT p.participant_id, p.session_id, se.session_name, p.user_id, u.name AS athlete, "
                   "p.attendance FROM Session_Participants p "
                   "LEFT JOIN Sessions se ON se.session_id = p.session_id "
                   "LEFT JOIN Users u ON u.user_id = p.user_id"),
        "order": "p.participant_id",
        "own": "p.user_id = :uid",
        "coach": "p.session_id IN " + _COACH_SESSIONS,
    },
    "Performance": {
        "select": ("SELECT pf.performance_id, pf.user_id, u.name AS athlete, pf.session_id, se.session_name, "
                   "pf.score, pf.duration_minutes, pf.remarks FROM Performance pf "
                   "LEFT JOIN Users u ON u.user_id = pf.user_id "
                   "LEFT JOIN Sessions se ON se.session_id = pf.session_id"),
        "order": "pf.performance_id",
        "own": "pf.user_id = :uid",
        "coach": "pf.session_id IN " + _COACH_SESSIONS,
    },
    "Notifications": {
        "select": ("SELECT n.notification_id, n.user_id, u.name AS recipient, n.message, "
                   "n.notification_date, n.status FROM Notifications n "
                   "LEFT JOIN Users u ON u.user_id = n.user_id"),
        "order": "n.notification_id",
        "own": "n.user_id = :uid",
    },
    "AuthLogs": {
        "select": ("SELECT l.log_id, l.user_id, u.name AS user_name, l.login_time, l.action, l.result "
                   "FROM AuthLogs l LEFT JOIN Users u ON u.user_id = l.user_id"),
        "order": "l.log_id",
        "own": "l.user_id = :uid",
    },
}
