import logging
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.exc import SQLAlchemyError
from .database import check_database_connection, ensure_auto_increment
from .routers import auth, catalog, users, records, dashboard

log = logging.getLogger("sportsync")
@asynccontextmanager
async def lifespan(_app: FastAPI):
    ensure_auto_increment()   # fixes "Field 'xxx_id' doesn't have a default value" on older databases
    yield


app = FastAPI(title="SportSync API", version="1.2.1", description="SportSync modular REST API", lifespan=lifespan)


# Registered BEFORE the CORS middleware so it sits inside it. Without this, an unexpected crash returns a bare 500
# with no CORS headers and the browser reports it as "Cannot connect to the API", hiding the real problem.
@app.middleware("http")
async def report_unexpected_errors(request: Request, call_next):
    try:
        return await call_next(request)
    except Exception as exc:  # noqa: BLE001 - last-resort handler
        log.exception("Unhandled error on %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=500,
            content={"detail": f"Server error ({exc.__class__.__name__}) on {request.url.path}. See the backend terminal for the full traceback."},
        )


app.add_middleware(CORSMiddleware, allow_origins=[os.getenv("FRONTEND_ORIGIN", "http://localhost:5173"), "http://127.0.0.1:5173", "http://localhost:5174", "http://127.0.0.1:5174"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(auth.router)
app.include_router(catalog.router)
app.include_router(users.router)
app.include_router(records.router)
app.include_router(dashboard.router)

@app.get("/")
def root():
    return {"name": "SportSync API", "docs": "/docs", "health": "/api/health"}

@app.get("/api/health", tags=["Health"])
def health():
    try:
        check_database_connection()
        return {"status": "ok", "database": "connected"}
    except SQLAlchemyError as exc:
        raise HTTPException(status_code=503, detail="Database connection failed. Check backend/.env and MySQL service.") from exc
