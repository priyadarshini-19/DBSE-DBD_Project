from sqlalchemy import String, Integer, Date, Time, ForeignKey, text
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

class User(Base):
    __tablename__ = "Users"
    user_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False, default="athlete")
    sport_preference: Mapped[str | None] = mapped_column(String(50))

class Sport(Base):
    __tablename__ = "Sports"
    sport_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sport_name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)

class Coach(Base):
    __tablename__ = "Coaches"
    coach_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    coach_name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str | None] = mapped_column(String(100))
    sport_id: Mapped[int | None] = mapped_column(ForeignKey("Sports.sport_id"))

class Session(Base):
    __tablename__ = "Sessions"
    session_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sport_id: Mapped[int | None] = mapped_column(ForeignKey("Sports.sport_id"))
    coach_id: Mapped[int | None] = mapped_column(ForeignKey("Coaches.coach_id"))
    session_name: Mapped[str] = mapped_column(String(100), nullable=False)
    session_date: Mapped[object | None] = mapped_column(Date)
    session_time: Mapped[object | None] = mapped_column(Time)
    location: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(20), default="scheduled")
