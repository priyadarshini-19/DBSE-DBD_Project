import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from passlib.context import CryptContext

pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

SECRET = os.getenv("JWT_SECRET", "")
if not SECRET or SECRET == "replace_with_a_long_random_secret_key" or len(SECRET) < 32:
    raise RuntimeError(
        "JWT_SECRET is missing, still the placeholder, or shorter than 32 characters. "
        "Set a strong value in backend/.env (generate one with: python -c \"import secrets; print(secrets.token_urlsafe(48))\")"
    )
ALGORITHM = "HS256"

def hash_password(value: str) -> str:
    return pwd.hash(value)

def verify_password(value: str, hashed: str) -> bool:
    # Legacy rows (e.g. plaintext 'demo123' from the sample SQL) are not valid bcrypt hashes;
    # treat them as a failed login instead of crashing with a 500.
    try:
        return pwd.verify(value, hashed)
    except (ValueError, TypeError):
        return False

def create_token(user_id: int, role: str):
    expiry = datetime.now(timezone.utc) + timedelta(minutes=int(os.getenv("ACCESS_TOKEN_MINUTES", "60")))
    return jwt.encode({"sub": str(user_id), "role": role, "exp": expiry}, SECRET, algorithm=ALGORITHM)

def decode_token(token: str):
    return jwt.decode(token, SECRET, algorithms=[ALGORITHM])
