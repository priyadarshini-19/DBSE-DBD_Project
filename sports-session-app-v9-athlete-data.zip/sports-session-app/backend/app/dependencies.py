from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from jose import JWTError
from .database import get_db
from .models import User
from .security import decode_token
bearer = HTTPBearer(auto_error=False)
def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer), db: Session = Depends(get_db)):
    if not creds: raise HTTPException(401, "Bearer token required")
    try: uid = int(decode_token(creds.credentials)["sub"])
    except (JWTError, ValueError, KeyError): raise HTTPException(401, "Invalid or expired token")
    user = db.get(User, uid)
    if not user: raise HTTPException(401, "User no longer exists")
    return user
def require_role(*roles):
    def check(user=Depends(current_user)):
        if (user.role or "").lower() not in roles: raise HTTPException(403, "Insufficient role")
        return user
    return check
