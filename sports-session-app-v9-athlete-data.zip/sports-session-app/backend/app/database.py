from pathlib import Path
import logging
import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is missing. Create backend/.env from backend/.env.example")
engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_recycle=3600)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def check_database_connection():
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))
    return True


log = logging.getLogger("sportsync.database")

# table -> primary-key column (same list used by prepare_database.py)
PRIMARY_KEYS = {
    "Users": "user_id", "Sports": "sport_id", "Coaches": "coach_id", "Sessions": "session_id",
    "Session_Participants": "participant_id", "Performance": "performance_id",
    "Notifications": "notification_id", "AuthLogs": "log_id",
}


def ensure_auto_increment():
    """Make every table's ID column AUTO_INCREMENT. Safe to run on every start: columns that already
    are auto-increment are left alone. Without this, inserts fail with
    "Field '<id>' doesn't have a default value" (e.g. creating a session or writing an AuthLogs row).
    Set AUTO_PREPARE_DB=false in backend/.env to skip."""
    if os.getenv("AUTO_PREPARE_DB", "true").strip().lower() in {"0", "false", "no", "off"}:
        return
    try:
        with engine.begin() as c:
            existing = {r[0].lower(): r[0] for r in c.execute(text(
                "SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE()"))}
            for table, col in PRIMARY_KEYS.items():
                real = existing.get(table.lower())
                if not real:
                    log.warning("Table %s not found - run database/original_schema.sql first.", table)
                    continue
                extra = c.execute(text(
                    "SELECT extra FROM information_schema.columns WHERE table_schema = DATABASE() "
                    "AND LOWER(table_name) = LOWER(:t) AND LOWER(column_name) = LOWER(:c)"),
                    {"t": table, "c": col}).scalar()
                if extra and "auto_increment" in extra.lower():
                    continue
                c.execute(text(f"ALTER TABLE `{real}` MODIFY `{col}` INT NOT NULL AUTO_INCREMENT"))
                log.warning("Fixed %s.%s: set to AUTO_INCREMENT", table, col)
    except Exception:  # noqa: BLE001 - never stop the API from starting
        log.exception("Automatic AUTO_INCREMENT check failed. Run `python prepare_database.py` manually.")
