from typing import Literal
from pydantic import BaseModel, EmailStr, Field, field_validator
from datetime import date, time

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: str = "athlete"
    sport_preference: str | None = Field(default=None, max_length=50)

    @field_validator("password")
    @classmethod
    def password_fits_bcrypt(cls, v: str) -> str:
        # bcrypt only uses the first 72 BYTES; reject longer input instead of silently truncating
        if len(v.encode("utf-8")) > 72:
            raise ValueError("Password must be at most 72 bytes")
        return v

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class SportIn(BaseModel):
    sport_name: str = Field(min_length=2, max_length=50)

class SessionIn(BaseModel):
    session_name: str = Field(min_length=2, max_length=100)
    sport_id: int
    coach_id: int | None = None
    session_date: date | None = None
    session_time: time | None = None
    location: str | None = Field(default=None, max_length=100)
    status: Literal["scheduled", "ongoing", "completed", "cancelled"] = "scheduled"


class SessionUpdate(BaseModel):
    """Partial update: only the fields that are sent are changed."""
    session_name: str | None = Field(default=None, min_length=2, max_length=100)
    sport_id: int | None = None
    coach_id: int | None = None
    session_date: date | None = None
    session_time: time | None = None
    location: str | None = Field(default=None, max_length=100)
    status: Literal["scheduled", "ongoing", "completed", "cancelled"] | None = None
