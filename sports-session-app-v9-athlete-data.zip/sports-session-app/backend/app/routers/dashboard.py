"""Read-only endpoints that feed every dashboard from the MySQL database."""
import logging
import os
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from .. import queries as q
from ..database import get_db
from ..dependencies import current_user, require_role

log = logging.getLogger("sportsync.dashboard")
router = APIRouter(prefix="/api", tags=["Dashboard data"])
PRIVILEGED = {"organizer", "admin"}

# "all"  -> every signed-in user sees every row in the Application Tables (matches the counts on the dashboard)
# "own"  -> non-organizer/admin users only see their own records in personal tables
TABLE_VIEW_SCOPE = os.getenv("TABLE_VIEW_SCOPE", "all").strip().lower()
# Maximum rows sent to the browser per table (the real total is always reported separately)
try:
    TABLE_ROW_LIMIT = max(1, int(os.getenv("TABLE_ROW_LIMIT", "1000")))
except ValueError:
    TABLE_ROW_LIMIT = 1000


def clean(value):
    """Make DB values JSON-friendly. PyMySQL returns TIME columns as timedelta, which FastAPI
    would otherwise serialise as a number of seconds."""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, timedelta):
        total = int(value.total_seconds())
        hours, rest = divmod(total, 3600)
        minutes, seconds = divmod(rest, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    if isinstance(value, time):
        return value.strftime("%H:%M:%S")
    if isinstance(value, Decimal):
        return float(value)
    return value


def run(db: Session, sql: str, params: dict | None = None, label: str = "data"):
    """Execute a SELECT and return (columns, rows). Real DB errors become a logged 500."""
    sql_params = {k: v for k, v in (params or {}).items() if f":{k}" in sql}
    try:
        result = db.execute(text(sql), sql_params)
        columns = list(result.keys())
        rows = [{k: clean(v) for k, v in row.items()} for row in result.mappings().all()]
        return columns, rows
    except SQLAlchemyError as exc:
        log.exception("Query failed while loading %s", label)
        raise HTTPException(500, f"Could not load {label} from the database. Check the backend log.") from exc


def rows_of(db, sql, params=None, label="data"):
    return run(db, sql, params, label)[1]


def one_of(db, sql, params=None, label="data"):
    rows = rows_of(db, sql, params, label)
    return rows[0] if rows else None


def coach_profile(db: Session, user, create: bool = False):
    """A coach login is linked to a row in Coaches through the shared email address.
    With create=True a missing row is created automatically so a new coach is never stuck on an empty dashboard."""
    row = one_of(db, q.COACH_BY_EMAIL, {"email": user.email or ""}, "coach profile")
    if row or not create:
        return row
    try:
        db.execute(
            text("INSERT INTO Coaches (coach_name, email, sport_id) "
                 "VALUES (:n, :e, (SELECT sport_id FROM Sports WHERE sport_name = :s LIMIT 1))"),
            {"n": user.name, "e": (user.email or "").lower(), "s": user.sport_preference},
        )
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        log.exception("Could not create a Coaches row for %s (has backend/prepare_database.py been run?)", user.email)
        return None
    return one_of(db, q.COACH_BY_EMAIL, {"email": user.email or ""}, "coach profile")


@router.get("/dashboard/summary")
def summary(db: Session = Depends(get_db), user=Depends(current_user)):
    return one_of(db, q.SUMMARY, label="summary")


@router.get("/coaches")
def coaches(db: Session = Depends(get_db), user=Depends(current_user)):
    return rows_of(db, q.COACHES, label="coaches")


@router.get("/dashboard/athlete")
def athlete_dashboard(db: Session = Depends(get_db), user=Depends(require_role("athlete"))):
    p = {"uid": user.user_id}
    sessions = rows_of(db, q.SESSION_SELECT + q.SESSION_ORDER, label="sessions")
    mine = rows_of(db, q.MY_PARTICIPATIONS, p, "your sessions")
    attendance = {m["session_id"]: m["attendance"] for m in mine}
    for s in sessions:
        s["joined"] = s["session_id"] in attendance
        s["attendance"] = attendance.get(s["session_id"])
    performance = rows_of(db, q.MY_PERFORMANCE, p, "your performance")
    notifications = rows_of(db, q.MY_NOTIFICATIONS, p, "your notifications")
    scores = [r["score"] for r in performance if r["score"] is not None]
    return {
        "sessions": sessions,
        "performance": performance,
        "notifications": notifications,
        "stats": {
            "sessions_joined": len(mine),
            "performance_records": len(performance),
            "average_score": round(sum(scores) / len(scores), 1) if scores else None,
            "unread_notifications": sum(1 for n in notifications if (n["status"] or "").lower() == "unread"),
        },
    }


@router.get("/dashboard/coach")
def coach_dashboard(db: Session = Depends(get_db), user=Depends(require_role("coach"))):
    coach = coach_profile(db, user, create=True)
    if not coach:
        return {"coach": None, "sessions": [], "athletes": [], "performance": [],
                "stats": {"athletes": 0, "sessions": 0, "performance_records": 0}}
    p = {"cid": coach["coach_id"]}
    sessions = rows_of(db, q.SESSION_SELECT + " WHERE se.coach_id = :cid" + q.SESSION_ORDER, p, "your sessions")
    # Athletes are grouped by the coach's sport; fall back to "athletes in my sessions" if the coach has no sport set.
    sport = coach.get("sport_name") or user.sport_preference
    if sport:
        athletes = rows_of(db, q.COACH_SPORT_ATHLETES, {"cid": coach["coach_id"], "sport": sport}, "your athletes")
    else:
        athletes = rows_of(db, q.COACH_ATHLETES, p, "your athletes")
    performance = rows_of(db, q.COACH_PERFORMANCE, p, "performance records")
    return {
        "coach": coach, "sessions": sessions, "athletes": athletes, "performance": performance,
        "stats": {"athletes": len(athletes), "sessions": len(sessions), "performance_records": len(performance)},
    }


@router.get("/dashboard/organizer")
def organizer_dashboard(db: Session = Depends(get_db), user=Depends(require_role("organizer", "admin"))):
    return {
        "sports": rows_of(db, q.SPORTS_WITH_COUNTS, label="sports"),
        "sessions": rows_of(db, q.SESSION_SELECT + q.SESSION_ORDER, label="sessions"),
        "coaches": rows_of(db, q.COACHES, label="coaches"),
        "stats": one_of(db, q.ORGANIZER_STATS, label="statistics"),
    }


@router.get("/tables/{table_name}")
def table_data(table_name: str, db: Session = Depends(get_db), user=Depends(current_user)):
    """Rows for the 'Application Tables' menu.

    By default (TABLE_VIEW_SCOPE=all) every signed-in user sees all rows, so the table always
    matches the count shown on the dashboard. Set TABLE_VIEW_SCOPE=own in backend/.env to restrict
    non-organizer/admin users to their own records in personal tables.
    """
    cfg = q.TABLES.get(table_name)
    if cfg is None:
        raise HTTPException(404, "Unknown table")
    role = (user.role or "").lower()
    params = {"uid": user.user_id}
    where, scope = None, "all"
    if TABLE_VIEW_SCOPE == "own" and role not in PRIVILEGED:
        if role == "coach":
            coach = coach_profile(db, user)
            params["cid"] = coach["coach_id"] if coach else None
            where = cfg.get("coach") or cfg.get("own")
        else:
            where = cfg.get("own")
        scope = "own" if where else "all"
    base_sql = cfg["select"] + (f" WHERE {where}" if where else "")
    # Real number of matching records (not limited), so the header shows the true total
    total = rows_of(db, f"SELECT COUNT(*) AS n FROM ({base_sql}) counted", params, table_name)[0]["n"]
    sql = base_sql + f" ORDER BY {cfg['order']} LIMIT {TABLE_ROW_LIMIT}"
    columns, rows = run(db, sql, params, table_name)
    return {"table": table_name, "scope": scope, "columns": columns, "rows": rows,
            "total": total, "shown": len(rows), "limit": TABLE_ROW_LIMIT}
