from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, text
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Sport, Session as TrainingSession, Coach
from ..schemas import SportIn, SessionIn, SessionUpdate
from ..dependencies import current_user, require_role
router=APIRouter(prefix="/api", tags=["Sports & sessions services"])
@router.get("/sports")
def sports(db:Session=Depends(get_db)):
    return [{"sport_id":x.sport_id,"sport_name":x.sport_name} for x in db.query(Sport).order_by(Sport.sport_id).all()]
@router.post("/sports",status_code=201)
def add_sport(data:SportIn, db:Session=Depends(get_db), user=Depends(require_role("organizer","admin"))):
    if db.query(Sport).filter_by(sport_name=data.sport_name).first(): raise HTTPException(409,"Sport already exists")
    x=Sport(sport_name=data.sport_name); db.add(x); db.commit(); db.refresh(x); return {"sport_id":x.sport_id,"sport_name":x.sport_name}
@router.get("/sessions")
def sessions(db:Session=Depends(get_db), user=Depends(current_user)):
    return [{"session_id":s.session_id,"session_name":s.session_name,"sport_id":s.sport_id,"coach_id":s.coach_id,"session_date":str(s.session_date) if s.session_date else None,"session_time":str(s.session_time) if s.session_time else None,"location":s.location,"status":s.status} for s in db.query(TrainingSession).order_by(TrainingSession.session_id.desc()).all()]
@router.post("/sessions",status_code=201)
def add_session(data:SessionIn,db:Session=Depends(get_db),user=Depends(require_role("coach","organizer","admin"))):
    if not db.get(Sport,data.sport_id): raise HTTPException(404,"Sport not found")
    payload=data.model_dump()
    if (user.role or "").lower()=="coach":
        # Coaches can only create sessions under their own coach profile (linked by email).
        me=db.query(Coach).filter(func.lower(Coach.email)==(user.email or "").lower()).first()
        if not me: raise HTTPException(400,"No coach profile is linked to your account email")
        payload["coach_id"]=me.coach_id
    elif data.coach_id is not None and not db.get(Coach,data.coach_id): raise HTTPException(404,"Coach not found")
    x=TrainingSession(**payload); db.add(x); db.commit(); db.refresh(x)
    return {"session_id":x.session_id,"session_name":x.session_name,"sport_id":x.sport_id,"coach_id":x.coach_id,"session_date":str(x.session_date) if x.session_date else None,"session_time":str(x.session_time) if x.session_time else None,"location":x.location,"status":x.status}


def _session_json(x):
    return {"session_id":x.session_id,"session_name":x.session_name,"sport_id":x.sport_id,"coach_id":x.coach_id,"session_date":str(x.session_date) if x.session_date else None,"session_time":str(x.session_time) if x.session_time else None,"location":x.location,"status":x.status}

def _own_coach(db, user):
    return db.query(Coach).filter(func.lower(Coach.email)==(user.email or "").lower()).first()

def _load_editable_session(db, session_id, user):
    """Organizers/admins may change any session; a coach only the sessions assigned to them."""
    x=db.get(TrainingSession,session_id)
    if not x: raise HTTPException(404,"Session not found")
    if (user.role or "").lower()=="coach":
        me=_own_coach(db,user)
        if not me or x.coach_id!=me.coach_id: raise HTTPException(403,"You can only change your own sessions")
    return x

@router.put("/sessions/{session_id}")
def update_session(session_id:int, data:SessionUpdate, db:Session=Depends(get_db), user=Depends(require_role("coach","organizer","admin"))):
    x=_load_editable_session(db,session_id,user)
    changes=data.model_dump(exclude_unset=True)
    if "session_name" in changes and changes["session_name"] is None: changes.pop("session_name")
    if "status" in changes and changes["status"] is None: changes.pop("status")
    if changes.get("sport_id") is not None and not db.get(Sport,changes["sport_id"]): raise HTTPException(404,"Sport not found")
    if "sport_id" in changes and changes["sport_id"] is None: changes.pop("sport_id")
    if (user.role or "").lower()=="coach":
        changes.pop("coach_id",None)   # a coach cannot hand their session to someone else
    elif changes.get("coach_id") is not None and not db.get(Coach,changes["coach_id"]): raise HTTPException(404,"Coach not found")
    for field,value in changes.items(): setattr(x,field,value)
    db.commit(); db.refresh(x)
    return _session_json(x)

@router.delete("/sessions/{session_id}")
def delete_session(session_id:int, db:Session=Depends(get_db), user=Depends(require_role("coach","organizer","admin"))):
    x=_load_editable_session(db,session_id,user)
    # The tables have no foreign-key cascade, so remove rows that belong to this session ourselves (one transaction).
    try:
        removed_participants=db.execute(text("DELETE FROM Session_Participants WHERE session_id=:sid"),{"sid":session_id}).rowcount
        removed_performance=db.execute(text("DELETE FROM Performance WHERE session_id=:sid"),{"sid":session_id}).rowcount
        db.delete(x); db.commit()
    except Exception as exc:
        db.rollback()
        raise HTTPException(500,f"Could not remove the session ({exc.__class__.__name__}).") from exc
    return {"deleted":session_id,"participants_removed":removed_participants,"performance_removed":removed_performance}
