from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..dependencies import require_role
router = APIRouter(prefix="/api", tags=["Users"])
@router.get("/users")
def get_users(db: Session = Depends(get_db), user=Depends(require_role("organizer", "admin"))):
    rows = db.query(User).order_by(User.user_id.desc()).all()
    return [{"user_id": u.user_id, "name": u.name, "email": u.email, "role": u.role, "sport_preference": u.sport_preference} for u in rows]
