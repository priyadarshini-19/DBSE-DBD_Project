import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, Coach, Sport
from ..schemas import RegisterIn, LoginIn
from ..security import hash_password, verify_password, create_token
from ..dependencies import current_user

log = logging.getLogger("sportsync.auth")
router=APIRouter(prefix="/api/auth", tags=["Auth service"])

def public(u): return {"user_id":u.user_id,"name":u.name,"email":u.email,"role":u.role,"sport_preference":u.sport_preference}

def log_auth(db: Session, user_id: int, result: str):
    """Best-effort write to the AuthLogs table; a logging problem must never block a login."""
    try:
        db.execute(text("INSERT INTO AuthLogs (user_id, login_time, action, result) VALUES (:u, :t, 'login', :r)"),
                   {"u": user_id, "t": datetime.now(), "r": result})
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        log.warning("Could not write to AuthLogs (has backend/prepare_database.py been run?)", exc_info=True)

@router.post("/register", status_code=201)
def register(data:RegisterIn, db:Session=Depends(get_db)):
    role=data.role.lower()
    # "admin" can never be self-assigned through the public endpoint; promote admins directly in the database.
    if role not in {"athlete","coach","organizer"}: raise HTTPException(422,"Unsupported role")
    email=data.email.lower()
    if db.query(User).filter_by(email=email).first(): raise HTTPException(409,"Email already registered")
    u=User(name=data.name,email=email,password_hash=hash_password(data.password),role=role,sport_preference=data.sport_preference)
    db.add(u)
    if role=="coach" and not db.query(Coach).filter(func.lower(Coach.email)==email).first():
        # A coach login is linked to the Coaches table through the shared email, so sessions can be assigned to them.
        sport=db.query(Sport).filter_by(sport_name=data.sport_preference).first() if data.sport_preference else None
        db.add(Coach(coach_name=data.name,email=email,sport_id=sport.sport_id if sport else None))
    db.commit(); db.refresh(u); return public(u)

@router.post("/login")
def login(data:LoginIn, db:Session=Depends(get_db)):
    u=db.query(User).filter_by(email=data.email.lower()).first()
    if not u or not verify_password(data.password,u.password_hash):
        if u: log_auth(db,u.user_id,"failed")
        raise HTTPException(401,"Invalid email or password")
    uid,role=u.user_id,u.role
    log_auth(db,uid,"success")
    return {"access_token":create_token(uid,role),"token_type":"bearer","user":public(u)}
@router.get("/me")
def me(user=Depends(current_user)): return public(user)
