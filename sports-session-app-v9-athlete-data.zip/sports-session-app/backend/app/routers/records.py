import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from pydantic import BaseModel
from ..database import get_db
from ..dependencies import current_user

log = logging.getLogger("sportsync.records")
router = APIRouter(prefix="/api", tags=["Athlete records"])
class JoinIn(BaseModel): session_id: int

def _fetch(db: Session, sql: str, uid: int, label: str):
    """Run a per-user read query. Real DB errors are logged and returned as 500
    instead of being disguised as an empty list."""
    try:
        return [dict(x) for x in db.execute(text(sql), {"uid": uid}).mappings().all()]
    except SQLAlchemyError as exc:
        log.exception("Failed to load %s", label)
        raise HTTPException(500, f"Could not load {label}. Check the backend log and that the table exists.") from exc

@router.get("/participants")
def participants(db: Session=Depends(get_db), user=Depends(current_user)):
    return _fetch(db, "SELECT participant_id, session_id, user_id, attendance FROM Session_Participants WHERE user_id=:uid", user.user_id, "participants")

@router.post("/participants", status_code=201)
def join(data: JoinIn, db: Session=Depends(get_db), user=Depends(current_user)):
    if not db.execute(text("SELECT session_id FROM Sessions WHERE session_id=:sid"), {"sid":data.session_id}).first(): raise HTTPException(404,"Session not found")
    exists=db.execute(text("SELECT participant_id FROM Session_Participants WHERE session_id=:sid AND user_id=:uid"), {"sid":data.session_id,"uid":user.user_id}).first()
    if exists: return {"message":"Already joined","session_id":data.session_id}
    try:
        next_id=db.execute(text("SELECT COALESCE(MAX(participant_id),0)+1 FROM Session_Participants")).scalar_one()
        db.execute(text("INSERT INTO Session_Participants (participant_id,session_id,user_id,attendance) VALUES (:pid,:sid,:uid,'registered')"), {"pid":next_id,"sid":data.session_id,"uid":user.user_id}); db.commit()
    except SQLAlchemyError as exc:
        db.rollback()
        log.exception("Failed to join session")
        raise HTTPException(409, "Could not join the session. Please try again.") from exc
    return {"participant_id":next_id,"session_id":data.session_id,"user_id":user.user_id,"attendance":"registered"}

@router.get("/performance")
def performance(db: Session=Depends(get_db), user=Depends(current_user)):
    return _fetch(db, "SELECT * FROM Performance WHERE user_id=:uid", user.user_id, "performance")

@router.get("/notifications")
def notifications(db: Session=Depends(get_db), user=Depends(current_user)):
    return _fetch(db, "SELECT * FROM Notifications WHERE user_id=:uid ORDER BY notification_id DESC", user.user_id, "notifications")

@router.get("/auth-logs")
def auth_logs(db: Session=Depends(get_db), user=Depends(current_user)):
    return _fetch(db, "SELECT * FROM AuthLogs WHERE user_id=:uid ORDER BY log_id DESC", user.user_id, "auth logs")
