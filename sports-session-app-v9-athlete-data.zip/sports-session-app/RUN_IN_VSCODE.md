# SportSync – run locally (Windows / VS Code)

Needs: Python 3.10+, Node.js, MySQL (running).

## 1. Load the database (once)
In MySQL Workbench open and run `database/original_schema.sql`
(same content as your `Match_Sports_Session.sql`). It creates `Match_Sports_Session` with all tables and sample data.
Do not run it again if the database already exists.

## 2. Backend
```powershell
cd backend
py -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```
Edit `backend\.env`:
- `DATABASE_URL` – put your MySQL password in place of `YOUR_MYSQL_PASSWORD`
- `JWT_SECRET` – paste the output of `python -c "import secrets; print(secrets.token_urlsafe(48))"`

Prepare the database for the API (one time, safe to re-run). It makes the ID columns auto-increment,
adds unique keys, hashes the sample passwords and creates a login for each coach:
```powershell
python prepare_database.py
```
Start the API (keep this terminal open):
```powershell
uvicorn app.main:app --reload
```
Check http://127.0.0.1:8000/api/health → `{"status":"ok","database":"connected"}` and http://127.0.0.1:8000/docs.

## 3. Frontend (second terminal, project root)
```powershell
npm install
npm run dev
```
Open the URL Vite prints (usually http://localhost:5173).

## 4. Log in with the sample data
Password for every sample account: `demo123` (local demo only – change it before sharing the database).

| Role      | Email                         | What you will see |
|-----------|-------------------------------|-------------------|
| Athlete   | rahul11@example.com           | own sessions, performance, notifications; join sessions |
| Coach     | rahul.coach@example.com       | own sessions, athletes, performance (created by `prepare_database.py`) |
| Organizer | organizer61@example.com       | all sports/sessions, add sports, create sessions, every table |
| Admin     | admin66@example.com           | same dashboard as organizer |

Use the ☰ menu → **Application Tables** to browse any MySQL table. Every row is shown.
All roles see the full table (counts and rows now match). To restrict athletes/coaches to their own rows, set `TABLE_VIEW_SCOPE=own` in `backend/.env`.
You can also register a new account in the UI.

## Troubleshooting
- **"Cannot connect to SportSync API"** – backend is not running or `VITE_API_BASE_URL` is wrong.
- **Health returns 503** – check `DATABASE_URL`/MySQL service.
- **"JWT_SECRET is missing…" on start** – set a 32+ character secret in `backend\.env`.
- **Login says "Invalid email or password" for sample users** – run `python prepare_database.py` (sample passwords were plaintext).
- **Register fails with a 500** – run `python prepare_database.py` (IDs must be auto-increment).
- **Coach dashboard says no coach profile** – the coach's login email must match a row in `Coaches` (registering as a coach creates one automatically).

## Postman
Import `postman/SportSync.postman_collection.json`, run Login first (it stores the token), then the other requests.
